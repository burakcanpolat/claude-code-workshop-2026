# VeloMax CRM Dashboard, English guide

An interactive sales controlling dashboard for the VeloMax CRM sample data. It reads the data snapshot and computes every chart, table and figure in the browser. The interface text itself stays in German on purpose: reading a German business tool with Claude's help is part of the exercise.

## Start it

**On macOS:** double click `start.command`.
If macOS warns about an unverified developer the first time: right click `start.command`, choose Open, then Open again. You only need to do that once.

**On Windows:** right click `start.ps1` and choose "Run with PowerShell" (or run `powershell -File start.ps1` from a terminal in this folder).

Either starter rebuilds the analysis and starts a local web server, then opens the dashboard in your browser. Close the terminal window (or press Ctrl+C) to stop the server.

**No Python on your machine?** The dashboard view will not start, but nothing else in the kit is lost. Claude can read the CSV files in `data_snapshot` directly and write the same reports; it is only slower than running the script.

## How a new month is added

The dashboard reads month folders under `data_snapshot/` (for example `2026-06`). Each folder holds the same six files, cumulative up to that month:

```
data_snapshot/
  2026-01/
  2026-02/
  ...
  2026-06/   <- newest so far
```

To add a new month: create a folder named `JJJJ-MM` (for example `2026-07`) with the same six file names inside, then rebuild the analysis (the starter script does this automatically, or run `scripts/build_monthly_analysis.py` yourself). The dashboard then shows the new month in the month picker automatically.

## What the analysis script does

`scripts/build_monthly_analysis.py` reads every complete month folder in `data_snapshot/`, checks the data for consistency (duplicate ids, references that point nowhere, totals that do not add up, stale open opportunities) and writes one JSON file per month plus an `index.json` summary into `analysis/`. Each month's status is `ready`, `ready_with_warnings`, or `blocked` depending on what it finds. The dashboard reads these files to show the executive summary and the automatic signals.

The `tests/` folder has a small automated test suite for the script (`test_monthly_analysis.py`), useful if you want to see how the checks are verified.
