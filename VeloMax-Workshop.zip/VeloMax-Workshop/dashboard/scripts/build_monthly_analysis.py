#!/usr/bin/env python3
"""Build deterministic analyses for all CRM snapshot folders."""
from __future__ import annotations
import argparse, csv, json, re
from collections import Counter, defaultdict
from datetime import date, datetime
from pathlib import Path

FILES={"activities":"aktivitaeten.csv","customers":"kunden.csv","opportunities":"opportunities.csv","products":"produkte.json","transactions":"sales_transactions.csv","staff":"vertriebsmitarbeiter.json"}
OPEN={"Lead","Qualified","Proposal","Negotiation"}

def rows_csv(path):
    with path.open(newline="",encoding="utf-8-sig") as f:return list(csv.DictReader(f))
def rows_json(path):
    with path.open(encoding="utf-8") as f:return json.load(f)
def dt(s):return datetime.strptime(s,"%Y-%m-%d").date() if s else None
def summarize(rows):
    revenue=sum(float(r["gesamt_eur"]) for r in rows); margin=sum(float(r["marge_eur"]) for r in rows)
    return {"transactions":len(rows),"units":sum(int(r["menge"]) for r in rows),"revenue":round(revenue,2),"margin":round(margin,2),"margin_pct":round(100*margin/revenue,1) if revenue else 0}
def end_of_month(month):
    y,m=map(int,month.split("-")); nxt=date(y+1,1,1) if m==12 else date(y,m+1,1)
    return date.fromordinal(nxt.toordinal()-1)
def delta(cur,prev):
    return {k:round(cur[k]-prev[k],2) for k in ("transactions","units","revenue","margin")}
def analyze(folder,month):
    missing=[f for f in FILES.values() if not (folder/f).is_file()]
    if missing:return {"month":month,"status":"blocked","hard_errors":["Fehlende Dateien: "+", ".join(missing)],"warnings":[]}
    try:
        act=rows_csv(folder/FILES["activities"]); cust=rows_csv(folder/FILES["customers"]); opp=rows_csv(folder/FILES["opportunities"]); prod=rows_json(folder/FILES["products"]); tx=rows_csv(folder/FILES["transactions"]); staff=rows_json(folder/FILES["staff"])
    except Exception as e:return {"month":month,"status":"blocked","hard_errors":[f"Lesefehler: {e}"],"warnings":[]}
    hard=[]; warnings=[]
    for label,rs,key in [("Aktivitäten",act,"aktivitaet_id"),("Kunden",cust,"kunde_id"),("Opportunities",opp,"opp_id"),("Transaktionen",tx,"transaktion_id"),("Produkte",prod,"produkt_id"),("Mitarbeiter",staff,"ma_id")]:
        ids=[r.get(key) for r in rs]
        if len(ids)!=len(set(ids)):hard.append(f"{label}: doppelte IDs")
    cids={r["kunde_id"] for r in cust}; pids={r["produkt_id"] for r in prod}; mids={r["ma_id"] for r in staff}
    refs=[("Aktivitäten→Kunden",act,"kunde_id",cids),("Aktivitäten→Mitarbeiter",act,"vertriebsmitarbeiter",mids),("Opportunities→Kunden",opp,"kunde_id",cids),("Opportunities→Produkte",opp,"produkt_id",pids),("Opportunities→Mitarbeiter",opp,"vertriebsmitarbeiter",mids),("Transaktionen→Kunden",tx,"kunde_id",cids),("Transaktionen→Produkte",tx,"produkt_id",pids),("Transaktionen→Mitarbeiter",tx,"vertriebsmitarbeiter",mids)]
    orphan_count=0
    for label,rs,key,valid in refs:
        n=sum(r.get(key) not in valid for r in rs); orphan_count+=n
        if n:hard.append(f"{label}: {n} verwaiste Referenzen")
    formula=sum(abs(float(r["gesamt_eur"])-int(r["menge"])*float(r["einzelpreis_eur"])*(1-float(r["rabatt_prozent"])/100))>.011 for r in tx)
    first_after=sum(bool(dt(r["erstkauf_datum"]) and dt(r["letzter_kauf"]) and dt(r["erstkauf_datum"])>dt(r["letzter_kauf"])) for r in cust)
    tx_count=Counter(r["kunde_id"] for r in tx); tx_rev=defaultdict(float)
    for r in tx:tx_rev[r["kunde_id"]]+=float(r["gesamt_eur"])
    count_mismatch=sum(int(r["anzahl_kaeufe"])!=tx_count[r["kunde_id"]] for r in cust)
    ltv_mismatch=sum(abs(float(r["lifetime_value_eur"])-tx_rev[r["kunde_id"]])>1 for r in cust)
    owner={r["kunde_id"]:r["vertriebsmitarbeiter"] for r in cust}; owner_mismatch=sum(owner.get(r["kunde_id"])!=r["vertriebsmitarbeiter"] for r in opp)
    snap=end_of_month(month); openo=[r for r in opp if r["stage"] in OPEN]
    stale=sum((snap-dt(r["letzte_aktivitaet"])).days>180 for r in openo)
    max_event=max([dt(r["datum"]) for r in tx]+[dt(r["datum"]) for r in act]+[dt(r["stage_datum"]) for r in opp])
    if max_event<date(snap.year,snap.month,1):warnings.append(f"Letztes Ereignis {max_event} liegt vor dem Snapshot-Monat.")
    if formula:warnings.append(f"{formula} Transaktionsformeln inkonsistent.")
    if first_after:warnings.append(f"{first_after} Kunden: Erstkauf nach letztem Kauf.")
    if count_mismatch or ltv_mismatch:warnings.append(f"Ledger-Abgleich: {count_mismatch} Kaufanzahl- und {ltv_mismatch} LTV-Abweichungen.")
    if owner_mismatch:warnings.append(f"{owner_mismatch} Opportunity-Owner weichen vom Kundenstamm ab.")
    if stale:warnings.append(f"{stale} von {len(openo)} offenen Opportunities sind >180 Tage inaktiv.")
    total=summarize(tx); channels=defaultdict(list); products=defaultdict(list); customers=defaultdict(list)
    pnames={r["produkt_id"]:r["modellname"] for r in prod}; cnames={r["kunde_id"]:r["name"] for r in cust}
    for r in tx:channels[r["vertriebskanal"]].append(r);products[pnames.get(r["produkt_id"],r["produkt_id"])].append(r);customers[r["kunde_id"]].append(r)
    won=[r for r in opp if r["stage"]=="Won"];lost=[r for r in opp if r["stage"]=="Lost"]
    pipeline={"open_count":len(openo),"open_value":round(sum(float(r["erwarteter_wert_eur"]) for r in openo),2),"weighted_open_value":round(sum(float(r["erwarteter_wert_eur"])*float(r["abschluss_wahrscheinlichkeit_prozent"])/100 for r in openo),2),"won_count":len(won),"lost_count":len(lost),"win_rate_pct":round(100*len(won)/(len(won)+len(lost)),1) if won or lost else 0,"stale_count":stale,"loss_reasons":dict(Counter(r["verlustgrund"] for r in lost))}
    top=sorted(((k,summarize(v)) for k,v in customers.items()),key=lambda x:x[1]["revenue"],reverse=True)[:5]
    risk_score=min(100,round((len(warnings)*10)+(stale/max(1,len(openo))*35)+(ltv_mismatch/max(1,len(cust))*25)))
    analysis=[]
    if stale:analysis.append({"type":"risk","label":"Pipeline-Hygiene","title":f"{stale} veraltete Chancen", "text":"Forecast vor Managemententscheidungen bereinigen; Owner und nächsten Schritt bestätigen.","evidence":f"{stale}/{len(openo)} offene Opportunities >180 Tage"})
    if pipeline["loss_reasons"]:
        reason=max(pipeline["loss_reasons"],key=pipeline["loss_reasons"].get); n=pipeline["loss_reasons"][reason]
        analysis.append({"type":"warning","label":"Verlustmuster","title":reason,"text":"Ursache nach Segment und Produkt prüfen; noch keine Kausalität ableiten.","evidence":f"{n} von {len(lost)} Lost Opportunities"})
    best=max(((k,summarize(v)) for k,v in products.items()),key=lambda x:x[1]["revenue"],default=("—",{"revenue":0}))
    analysis.append({"type":"opportunity","label":"Produktführer","title":best[0],"text":"Umsatzführer im kumulierten Snapshot; Margen- und Kanalmix vor Ausbau prüfen.","evidence":f"{best[1]['revenue']:.2f} EUR Umsatz"})
    return {"month":month,"status":"blocked" if hard else "ready_with_warnings" if warnings else "ready","snapshot_end":str(snap),"source_folder":str(folder),"row_counts":{"activities":len(act),"customers":len(cust),"opportunities":len(opp),"products":len(prod),"transactions":len(tx),"staff":len(staff)},"event_ranges":{"transactions":[str(min(dt(r["datum"]) for r in tx)),str(max(dt(r["datum"]) for r in tx))],"activities":[str(min(dt(r["datum"]) for r in act)),str(max(dt(r["datum"]) for r in act))]},"hard_errors":hard,"warnings":warnings,"sales_total":total,"sales_by_channel":{k:summarize(v) for k,v in channels.items()},"sales_by_product":{k:summarize(v) for k,v in products.items()},"top_customers":[{"kunde_id":k,"name":cnames.get(k,k),**v} for k,v in top],"pipeline":pipeline,"data_quality":{"score":max(0,100-risk_score),"risk_score":risk_score,"formula_mismatches":formula,"first_after_last":first_after,"purchase_count_mismatches":count_mismatch,"ltv_mismatches":ltv_mismatch,"owner_mismatches":owner_mismatch,"orphan_references":orphan_count},"management_analysis":analysis}

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--source",required=True);ap.add_argument("--output",required=True);a=ap.parse_args()
    src=Path(a.source).expanduser().resolve();out=Path(a.output).expanduser().resolve();out.mkdir(parents=True,exist_ok=True)
    months=sorted(p.name for p in src.iterdir() if p.is_dir() and re.fullmatch(r"\d{4}-\d{2}",p.name))
    snapshots=[];prev=None
    for month in months:
        item=analyze(src/month,month)
        if "sales_total" in item:
            item["snapshot_delta"]=delta(item["sales_total"],prev["sales_total"]) if prev and "sales_total" in prev else dict(item["sales_total"])
        (out/f"{month}.json").write_text(json.dumps(item,ensure_ascii=False,indent=2),encoding="utf-8")
        snapshots.append(item);prev=item
    compact=[]
    for x in snapshots:
        compact.append({k:x[k] for k in ("month","status","row_counts","sales_total","snapshot_delta","pipeline","data_quality","warnings") if k in x})
    index={"generated_at":datetime.now().astimezone().isoformat(),"source":str(src),"months":months,"latest_month":months[-1] if months else None,"snapshots":compact}
    (out/"index.json").write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({"status":"ok","months":len(months),"output":str(out)},ensure_ascii=False))
if __name__=="__main__":main()
