/* ===========================================================================
   VeloMax CRM Dashboard — liest die Rohdaten live aus ./data und berechnet
   alle Kennzahlen, Charts und Tabellen clientseitig.
   "Aktualisieren" lädt die Dateien neu (Cache-Bust) und rechnet alles neu.
   =========================================================================== */

let DATA_ROOT = 'data/';       // 'data/' = Live-Symlink, 'data_snapshot/' = lokale Momentaufnahme
let DATA_DIR  = 'data/';       // effektiver Ordner: DATA_ROOT + Monat
let DATA_LIVE = true;
let MONTHS = [];               // verfügbare Monatsordner, z.B. ['2026-02','2026-01'] (neueste zuerst)
let CURRENT_MONTH = '';        // gewählter Monat; '' = Dateien liegen direkt in data/ (Altmodus)
const FILES = {
  tx:       'sales_transactions.csv',
  kunden:   'kunden.csv',
  opps:     'opportunities.csv',
  akt:      'aktivitaeten.csv',
  produkte: 'produkte.json',
  ma:       'vertriebsmitarbeiter.json',
};

const PALETTE = ['#4361ee','#7c3aed','#0ea5e9','#10b981','#f59e0b','#ef4444','#ec4899','#14b8a6','#8b5cf6','#f97316'];

// ---------- global state ----------
const DB = {};            // raw + enriched datasets
const ANALYSIS = { index:null, current:null };
const charts = {};        // active Chart instances by canvas id
let FILTERS = defaultFilters();
let MAXDATE = '';         // latest transaction date in dataset

function defaultFilters() {
  return { jahr:'', kanal:'', land:'', ma:'', modell:'', segment:'', typ:'' };
}

// ---------- formatting ----------
const fEUR  = new Intl.NumberFormat('de-DE', { style:'currency', currency:'EUR', maximumFractionDigits:0 });
const fEUR1 = new Intl.NumberFormat('de-DE', { maximumFractionDigits:0 });
const fNUM  = new Intl.NumberFormat('de-DE');
const eur  = n => fEUR.format(Math.round(n||0));
const num  = n => fNUM.format(n||0);
const pct  = n => (isFinite(n)?n.toFixed(1):'0') + ' %';
function eurShort(n){ n=n||0; const a=Math.abs(n);
  if(a>=1e6) return (n/1e6).toLocaleString('de-DE',{maximumFractionDigits:2})+' Mio €';
  if(a>=1e3) return Math.round(n/1e3).toLocaleString('de-DE')+' T€';
  return eur(n);
}

// ---------- loading ----------
async function loadCSV(file){
  const url = DATA_DIR + file + '?t=' + Date.now();
  return new Promise((resolve,reject)=>{
    Papa.parse(url, {
      download:true, header:true, dynamicTyping:true, skipEmptyLines:true,
      complete: r => resolve(r.data.filter(row => Object.keys(row).length>1)),
      error: err => reject(new Error('CSV '+file+': '+err.message)),
    });
  });
}
async function loadJSON(file){
  const res = await fetch(DATA_DIR + file + '?t=' + Date.now());
  if(!res.ok) throw new Error('JSON '+file+': HTTP '+res.status);
  return res.json();
}

async function loadAnalysis(){
  const indexRes = await fetch('analysis/index.json?t='+Date.now(), {cache:'no-store'});
  if(!indexRes.ok) throw new Error('Analyseindex nicht verfügbar: HTTP '+indexRes.status);
  ANALYSIS.index = await indexRes.json();
  const month = CURRENT_MONTH || ANALYSIS.index.latest_month;
  const currentRes = await fetch('analysis/'+month+'.json?t='+Date.now(), {cache:'no-store'});
  if(!currentRes.ok) throw new Error('Monatsanalyse '+month+' nicht verfügbar');
  ANALYSIS.current = await currentRes.json();
}

function fetchSix(){
  return Promise.all([
    loadCSV(FILES.tx), loadCSV(FILES.kunden), loadCSV(FILES.opps),
    loadCSV(FILES.akt), loadJSON(FILES.produkte), loadJSON(FILES.ma),
  ]);
}

// Monatsordner (JJJJ-MM) im Wurzelordner entdecken — über das Verzeichnis-Listing
// des lokalen Servers. Neueste zuerst.
async function discoverMonths(root){
  const r = await fetch(root + '?t=' + Date.now(), {cache:'no-store'});
  if(!r.ok) throw new Error('Ordnerliste nicht lesbar (HTTP ' + r.status + ')');
  const html = await r.text();
  const ids = [...html.matchAll(/href="(\d{4}-\d{2})\/?"/g)].map(m => m[1]);
  return [...new Set(ids)].sort().reverse();
}

// Gewählten Monat beibehalten, wenn er noch existiert — sonst neuesten nehmen.
function pickMonth(months){
  if(CURRENT_MONTH && months.includes(CURRENT_MONTH)) return CURRENT_MONTH;
  return months[0];
}

async function resolveRoot(root){
  // Liefert die Monatsliste des Wurzelordners; ohne Monatsordner wird geprüft,
  // ob die Dateien direkt dort liegen (Altmodus '' ).
  let months = [];
  try{ months = await discoverMonths(root); }catch(e){ /* Listing nicht verfügbar */ }
  if(months.length) return months;
  const p = await fetch(root + FILES.produkte + '?probe=' + Date.now(), {cache:'no-store'});
  if(!p.ok) throw new Error('weder Monatsordner noch Dateien in ' + root);
  return [''];
}

async function loadAll(){
  // Primär Live-Daten (Symlink auf den CRM-Hauptordner mit Monatsordnern).
  // Scheitert irgendetwas (z.B. Sandbox der In-App-Vorschau oder nicht
  // materialisierte Drive-Dateien), wird komplett auf die lokale
  // Momentaufnahme zurückgefallen.
  let six, months;
  try{
    DATA_ROOT='data/'; DATA_LIVE=true;
    months = await resolveRoot(DATA_ROOT);
    CURRENT_MONTH = pickMonth(months);
    DATA_DIR = DATA_ROOT + (CURRENT_MONTH ? CURRENT_MONTH + '/' : '');
    six = await fetchSix();
  }catch(e){
    console.warn('Live-Daten nicht erreichbar, nutze Momentaufnahme:', e.message);
    DATA_ROOT='data_snapshot/'; DATA_LIVE=false;
    months = await resolveRoot(DATA_ROOT);
    CURRENT_MONTH = pickMonth(months);
    DATA_DIR = DATA_ROOT + (CURRENT_MONTH ? CURRENT_MONTH + '/' : '');
    six = await fetchSix();
  }
  MONTHS = months;
  const [tx, kunden, opps, akt, produkte, ma] = six;

  // indices
  const kById = Object.fromEntries(kunden.map(k => [k.kunde_id, k]));
  const pById = Object.fromEntries(produkte.map(p => [p.produkt_id, p]));
  const mById = Object.fromEntries(ma.map(m => [m.ma_id, m]));

  // enrich transactions with customer + product attributes
  tx.forEach(t => {
    const k = kById[t.kunde_id] || {};
    const p = pById[t.produkt_id] || {};
    t.land     = k.land || '—';
    t.segment  = k.kundensegment || '—';
    t.ktyp     = k.typ || '—';
    t.kname    = k.name || t.kunde_id;
    t.modell   = p.modellname || t.produkt_id;
    t.kategorie= p.kategorie || '—';
    t.maname   = (mById[t.vertriebsmitarbeiter]||{}).name || t.vertriebsmitarbeiter;
    t.jahr     = String(t.datum||'').slice(0,4);
    t.monat    = String(t.datum||'').slice(0,7);
  });
  opps.forEach(o => {
    const k = kById[o.kunde_id] || {};
    o.land=k.land||'—'; o.segment=k.kundensegment||'—'; o.ktyp=k.typ||'—'; o.kname=k.name||o.kunde_id;
    o.modell=(pById[o.produkt_id]||{}).modellname||o.produkt_id;
    o.maname=(mById[o.vertriebsmitarbeiter]||{}).name||o.vertriebsmitarbeiter;
  });

  Object.assign(DB, { tx, kunden, opps, akt, produkte, ma, kById, pById, mById });
  MAXDATE = tx.reduce((m,t)=> t.datum>m ? t.datum : m, '');
  try { await loadAnalysis(); }
  catch(e) { console.warn('Agentenanalyse nicht verfügbar:', e.message); ANALYSIS.current=null; }
}

// ---------- filtering ----------
function txFiltered(){
  const f = FILTERS;
  return DB.tx.filter(t =>
    (!f.jahr    || t.jahr===f.jahr) &&
    (!f.kanal   || t.vertriebskanal===f.kanal) &&
    (!f.land    || t.land===f.land) &&
    (!f.ma      || t.vertriebsmitarbeiter===f.ma) &&
    (!f.modell  || t.produkt_id===f.modell) &&
    (!f.segment || t.segment===f.segment) &&
    (!f.typ     || t.ktyp===f.typ)
  );
}
function kundenFiltered(){
  const f = FILTERS;
  return DB.kunden.filter(k =>
    (!f.land    || k.land===f.land) &&
    (!f.ma      || k.vertriebsmitarbeiter===f.ma) &&
    (!f.segment || k.kundensegment===f.segment) &&
    (!f.typ     || k.typ===f.typ)
  );
}
function oppsFiltered(){
  const f = FILTERS;
  return DB.opps.filter(o =>
    (!f.land    || o.land===f.land) &&
    (!f.ma      || o.vertriebsmitarbeiter===f.ma) &&
    (!f.modell  || o.produkt_id===f.modell) &&
    (!f.segment || o.segment===f.segment) &&
    (!f.typ     || o.ktyp===f.typ)
  );
}

// ---------- aggregation helpers ----------
function sumBy(rows, keyFn, valFn){
  const m = new Map();
  rows.forEach(r => { const k=keyFn(r); m.set(k,(m.get(k)||0)+(valFn(r)||0)); });
  return m;
}
function countBy(rows, keyFn){
  const m = new Map();
  rows.forEach(r => { const k=keyFn(r); m.set(k,(m.get(k)||0)+1); });
  return m;
}
const mapToSorted = m => [...m.entries()].sort((a,b)=>b[1]-a[1]);

// ---------- chart factory ----------
Chart.defaults.font.family = getComputedStyle(document.body).fontFamily;
Chart.defaults.font.size = 12;
Chart.defaults.color = '#5a6781';
Chart.defaults.plugins.legend.labels.usePointStyle = true;
Chart.defaults.plugins.legend.labels.boxWidth = 8;
Chart.defaults.plugins.legend.labels.padding = 14;

function makeChart(id, config){
  if(charts[id]) charts[id].destroy();
  const el = document.getElementById(id);
  if(!el) return;
  charts[id] = new Chart(el.getContext('2d'), config);
}
const euroTick = v => eurShort(v);
const tipEUR = ctx => ' ' + eur(ctx.parsed.y ?? ctx.parsed);
function gridY(){ return { grid:{color:'#eef1f7',drawBorder:false}, ticks:{callback:euroTick}, border:{display:false} }; }
function gridX(){ return { grid:{display:false}, border:{display:false} }; }

// ===========================================================================
//  RENDER — OVERVIEW
// ===========================================================================
function renderOverview(){
  const tx = txFiltered();
  const umsatz = tx.reduce((s,t)=>s+t.gesamt_eur,0);
  const marge  = tx.reduce((s,t)=>s+t.marge_eur,0);
  const n = tx.length;
  const margePct = umsatz ? marge/umsatz*100 : 0;
  const avg = n ? umsatz/n : 0;

  const byMa   = mapToSorted(sumBy(tx, t=>t.maname, t=>t.gesamt_eur));
  const byLand = mapToSorted(sumBy(tx, t=>t.land,  t=>t.gesamt_eur));
  const byMod  = mapToSorted(sumBy(tx, t=>t.modell,t=>t.gesamt_eur));

  const kpis = [
    {cls:'g1', label:'Gesamtumsatz', value:eur(umsatz), foot:scopeLabel()},
    {cls:'g2', label:'Marge gesamt', value:eur(marge), foot:'Deckungsbeitrag'},
    {cls:'g2', label:'Marge in %', value:pct(margePct), foot:'vom Umsatz'},
    {cls:'g3', label:'Ø Auftragswert', value:eur(avg), foot:num(n)+' Transaktionen'},
    {cls:'g2', label:'Transaktionen', value:num(n), foot:scopeLabel(), sm:false},
    {cls:'g1', label:'Top-Mitarbeiter', value:(byMa[0]?byMa[0][0]:'—'), foot:byMa[0]?eur(byMa[0][1])+' Umsatz':'', sm:true},
    {cls:'g3', label:'Top-Land', value:(byLand[0]?byLand[0][0]:'—'), foot:byLand[0]?eur(byLand[0][1])+' Umsatz':'', sm:true},
    {cls:'g4', label:'Top-Modell', value:(byMod[0]?byMod[0][0]:'—'), foot:byMod[0]?eur(byMod[0][1])+' Umsatz':'', sm:true},
  ];
  document.getElementById('kpi-grid').innerHTML = kpis.map(kpiHTML).join('');

  // monthly umsatz + marge
  const months = [...new Set(tx.map(t=>t.monat))].sort();
  const umByM = sumBy(tx, t=>t.monat, t=>t.gesamt_eur);
  const maByM = sumBy(tx, t=>t.monat, t=>t.marge_eur);
  makeChart('c-month', {
    type:'line',
    data:{ labels: months.map(fmtMonth), datasets:[
      { label:'Umsatz', data:months.map(m=>umByM.get(m)||0), borderColor:'#3b82f6', backgroundColor:'rgba(59,130,246,.12)', fill:true, tension:.35, borderWidth:3, pointRadius:3, pointBackgroundColor:'#3b82f6' },
      { label:'Marge',  data:months.map(m=>maByM.get(m)||0), borderColor:'#10b981', backgroundColor:'rgba(16,185,129,.10)', fill:true, tension:.35, borderWidth:3, pointRadius:3, pointBackgroundColor:'#10b981' },
    ]},
    options:{ responsive:true, maintainAspectRatio:false,
      interaction:{mode:'index',intersect:false},
      plugins:{ legend:{position:'top',align:'end'}, tooltip:{callbacks:{label:c=>` ${c.dataset.label}: ${eur(c.parsed.y)}`}}},
      scales:{ y:gridY(), x:gridX() } }
  });

  // channel bars (umsatz + marge)
  const chans = [...new Set(tx.map(t=>t.vertriebskanal))];
  const umByC = sumBy(tx, t=>t.vertriebskanal, t=>t.gesamt_eur);
  const maByC = sumBy(tx, t=>t.vertriebskanal, t=>t.marge_eur);
  makeChart('c-channel', {
    type:'bar',
    data:{ labels:chans, datasets:[
      { label:'Umsatz', data:chans.map(c=>umByC.get(c)||0), backgroundColor:'#4361ee', borderRadius:8, maxBarThickness:64 },
      { label:'Marge',  data:chans.map(c=>maByC.get(c)||0), backgroundColor:'#10b981', borderRadius:8, maxBarThickness:64 },
    ]},
    options:{ responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{position:'top',align:'end'}, tooltip:{callbacks:{label:c=>` ${c.dataset.label}: ${eur(c.parsed.y)}`}}},
      scales:{ y:gridY(), x:gridX() } }
  });

  donut('c-country', byLand.slice(0,8));
  donut('c-model',  byMod.map(([k,v])=>[k.replace(/^VeloMax\s+/,''), v]));
  donut('c-segment', mapToSorted(sumBy(tx, t=>t.segment, t=>t.gesamt_eur)));

  renderInsights();
}

function donut(id, entries){
  const labels = entries.map(e=>e[0]);
  const data = entries.map(e=>e[1]);
  makeChart(id, {
    type:'doughnut',
    data:{ labels, datasets:[{ data, backgroundColor:PALETTE, borderWidth:2, borderColor:'#fff', hoverOffset:6 }]},
    options:{ responsive:true, maintainAspectRatio:false, cutout:'62%',
      plugins:{ legend:{position:'right'}, tooltip:{callbacks:{label:c=>{
        const tot=data.reduce((a,b)=>a+b,0); return ` ${c.label}: ${eur(c.parsed)} (${pct(c.parsed/tot*100)})`;
      }}}} }
  });
}

function kpiHTML(k){
  return `<div class="kpi ${k.cls}">
    <div class="k-label">${k.label}</div>
    <div class="k-value ${k.sm?'sm':''}">${k.value}</div>
    <div class="k-foot">${k.foot||''}</div>
  </div>`;
}

function scopeLabel(){
  const p=[];
  if(FILTERS.jahr) p.push(FILTERS.jahr); else p.push('2024–2025');
  if(FILTERS.kanal) p.push(FILTERS.kanal);
  if(FILTERS.land) p.push(FILTERS.land);
  return p.join(' · ');
}
function fmtMonth(m){
  const [y,mm]=m.split('-'); const names=['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'];
  return names[parseInt(mm,10)-1]+' '+y.slice(2);
}

// ---------- auto insights (robust gegen Datenänderungen) ----------
function renderInsights(){
  const out = [];
  // 1) top loss reason
  const lost = DB.opps.filter(o=>o.stage==='Lost' && o.verlustgrund);
  if(lost.length){
    const lr = mapToSorted(countBy(lost, o=>o.verlustgrund));
    out.push({cls:'warn', ico:'⚠️', title:'Häufigster Verlustgrund: '+lr[0][0],
      text:`${lr[0][1]} von ${lost.length} verlorenen Opportunities (${pct(lr[0][1]/lost.length*100)}).`});
  }
  // 2) best growth country YoY
  const cy = {}, py = {};
  DB.tx.forEach(t=>{ if(t.jahr==='2025') cy[t.land]=(cy[t.land]||0)+t.gesamt_eur; if(t.jahr==='2024') py[t.land]=(py[t.land]||0)+t.gesamt_eur; });
  let best=null;
  Object.keys(cy).forEach(l=>{ if((py[l]||0)>50000){ const d=cy[l]-py[l], g=d/py[l]*100; if(!best||d>best.d) best={l,d,g,cy:cy[l]}; }});
  if(best && best.d>0) out.push({cls:'good', ico:'📈', title:'Wachstumsmarkt: '+best.l,
    text:`+${best.g.toFixed(0)} % auf ${eur(best.cy)} (+${eurShort(best.d)} ggü. 2024) — größter Zuwachs. Vertriebsressourcen prüfen.`});
  // 3) weakest win-rate MA
  const maStats={};
  DB.opps.forEach(o=>{ if(o.stage==='Won'||o.stage==='Lost'){ const s=maStats[o.maname]||(maStats[o.maname]={w:0,t:0}); s.t++; if(o.stage==='Won')s.w++; }});
  let weak=null;
  Object.entries(maStats).forEach(([n,s])=>{ if(s.t>=5){ const wr=s.w/s.t*100; if(!weak||wr<weak.wr) weak={n,wr,t:s.t}; }});
  if(weak) out.push({cls:'alert', ico:'🚩', title:'Schwache Conversion: '+weak.n,
    text:`Win-Rate ${weak.wr.toFixed(0)} % über ${weak.t} entschiedene Opportunities — Coaching-Bedarf prüfen.`});
  // 4) biggest B2B revenue drop YoY
  const c24={},c25={};
  DB.tx.forEach(t=>{ if(t.ktyp==='B2B'){ if(t.jahr==='2024')c24[t.kname]=(c24[t.kname]||0)+t.gesamt_eur; if(t.jahr==='2025')c25[t.kname]=(c25[t.kname]||0)+t.gesamt_eur; }});
  let drop=null;
  Object.keys(c24).forEach(k=>{ if(c24[k]>50000){ const d=(c25[k]||0)-c24[k]; if(!drop||d<drop.d) drop={k,d,from:c24[k],to:c25[k]||0}; }});
  if(drop && drop.d<0) out.push({cls:'alert', ico:'📉', title:'Umsatzeinbruch: '+drop.k,
    text:`${eur(drop.from)} (2024) → ${eur(drop.to)} (2025), ${((drop.d/drop.from)*100).toFixed(0)} %. Abwanderungsrisiko.`});
  // 5) model channel skew
  const skew=[];
  DB.produkte.forEach(p=>{
    const web=DB.tx.filter(t=>t.produkt_id===p.produkt_id&&t.vertriebskanal==='Webshop').reduce((s,t)=>s+t.menge,0);
    const gh =DB.tx.filter(t=>t.produkt_id===p.produkt_id&&t.vertriebskanal==='Grosshandel').reduce((s,t)=>s+t.menge,0);
    if(web+gh>=15){ const ratio=Math.max(web,gh)/Math.max(1,Math.min(web,gh)); skew.push({p:p.modellname,web,gh,ratio}); }
  });
  skew.sort((a,b)=>b.ratio-a.ratio);
  if(skew[0]&&skew[0].ratio>=5) out.push({cls:'warn', ico:'🔀', title:'Kanal-Schieflage: '+skew[0].p,
    text:`Webshop ${skew[0].web} Stk. vs. Großhandel ${skew[0].gh} Stk. — Distributionslücke im Fachhandel?`});

  document.getElementById('insights').innerHTML = out.map(i=>`
    <div class="insight ${i.cls}">
      <div class="i-ico">${i.ico}</div>
      <div><div class="i-title">${i.title}</div><div class="i-text">${i.text}</div></div>
    </div>`).join('') || '<div class="i-text">Keine Auffälligkeiten im aktuellen Datenstand.</div>';
}

// ===========================================================================
//  RENDER — AGENTISCHE MONATSANALYSE
// ===========================================================================
function renderMonatsanalyse(){
  const a=ANALYSIS.current, idx=ANALYSIS.index;
  if(!a || !idx){
    document.getElementById('analysis-lead').textContent='Analyseartefakte fehlen. Bitte scripts/build_monthly_analysis.py ausführen.';
    return;
  }
  document.getElementById('analysis-title').textContent='Briefing · '+monthLabel(a.month);
  document.getElementById('analysis-lead').textContent=`Snapshot ${a.month} · Transaktionen ${a.event_ranges.transactions[0]} bis ${a.event_ranges.transactions[1]} · ${a.warnings.length} sichtbare Warnungen`;
  const score=a.data_quality.score;
  const orb=document.getElementById('quality-orb');
  orb.className='quality-orb '+(score>=80?'good':score>=60?'warn':'bad');
  orb.innerHTML=`<strong>${score}</strong><span>Datenqualität</span>`;
  const d=a.snapshot_delta, p=a.pipeline, s=a.sales_total;
  document.getElementById('analysis-kpis').innerHTML=[
    {cls:'dark-violet',label:'Neu im Snapshot',value:eur(d.revenue),foot:`${num(d.transactions)} zusätzliche Transaktionen`},
    {cls:'dark-blue',label:'Kumuliertes Ledger',value:eur(s.revenue),foot:`${num(s.units)} Einheiten · ${pct(s.margin_pct)} Marge`},
    {cls:'dark-green',label:'Gewichtete Pipeline',value:eur(p.weighted_open_value),foot:`${num(p.open_count)} offene Opportunities`},
    {cls:p.stale_count?'dark-red':'dark-green',label:'Überalterte Chancen',value:num(p.stale_count),foot:'mehr als 180 Tage ohne Aktivität'},
  ].map(kpiHTML).join('');
  const snaps=idx.snapshots.filter(x=>x.snapshot_delta);
  const changeSnaps=snaps.slice(1); // Januar ist der Ausgangsbestand, keine Monatsveränderung
  makeChart('c-snapshot-trend',{type:'bar',data:{labels:changeSnaps.map(x=>monthLabel(x.month)),datasets:[
    {label:'Neuer Umsatz',data:changeSnaps.map(x=>x.snapshot_delta.revenue),backgroundColor:'#7170ff',borderRadius:7,maxBarThickness:44},
    {label:'Neue Marge',data:changeSnaps.map(x=>x.snapshot_delta.margin),backgroundColor:'#27a644',borderRadius:7,maxBarThickness:44},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'top',align:'end'},tooltip:{callbacks:{label:c=>` ${c.dataset.label}: ${eur(c.parsed.y)}`}}},scales:{y:darkGridY(),x:darkGridX()}}});
  const stalePct=p.open_count?p.stale_count/p.open_count*100:0;
  document.getElementById('pipeline-health').innerHTML=`
    <div class="health-metric"><span>Offener Wert</span><strong>${eur(p.open_value)}</strong></div>
    <div class="health-metric"><span>Gewichtet</span><strong>${eur(p.weighted_open_value)}</strong></div>
    <div class="health-metric"><span>Closed Win Rate</span><strong>${pct(p.win_rate_pct)}</strong></div>
    <div class="health-bar"><div style="width:${Math.min(100,stalePct)}%"></div></div>
    <p><b>${p.stale_count}</b> von ${p.open_count} offenen Chancen sind überaltert. Pipelinewert vor Forecast-Freigabe validieren.</p>`;
  document.getElementById('agent-signals').innerHTML=a.management_analysis.map(x=>`<article class="signal ${x.type}"><div class="signal-top"><span>${x.label}</span><em>${x.type==='opportunity'?'Vorschlag':x.type==='risk'?'Risiko':'Hypothese'}</em></div><h4>${x.title}</h4><p>${x.text}</p><small>Beleg · ${x.evidence}</small></article>`).join('');
  const quality=[...a.hard_errors.map(x=>({kind:'block',text:x})),...a.warnings.map(x=>({kind:'warn',text:x}))];
  document.getElementById('quality-list').innerHTML=quality.map(x=>`<div class="quality-row"><i class="${x.kind}"></i><div><strong>${x.kind==='block'?'Blocker':'Warnung'}</strong><span>${x.text}</span></div></div>`).join('')||'<div class="quality-row"><i class="ok"></i><div><strong>Bereit</strong><span>Keine Qualitätswarnungen erkannt.</span></div></div>';
  renderTable('t-monthly',[
    {key:'month',label:'Snapshot',render:r=>`<strong>${monthLabel(r.month)}</strong>`,sortVal:r=>r.month},
    {key:'status',label:'Status',render:r=>`<span class="pill ${r.status==='ready'?'ok':r.status==='blocked'?'bad':'warn'}">${r.status}</span>`,sortVal:r=>r.status},
    {key:'revenue',label:'Ledger gesamt',num:true,render:r=>eur(r.sales_total.revenue),sortVal:r=>r.sales_total.revenue},
    {key:'delta',label:'Neu seit Vormonat',num:true,render:r=>eur(r.snapshot_delta.revenue),sortVal:r=>r.snapshot_delta.revenue},
    {key:'margin',label:'Neue Marge',num:true,render:r=>eur(r.snapshot_delta.margin),sortVal:r=>r.snapshot_delta.margin},
    {key:'pipeline',label:'Gewichtete Pipeline',num:true,render:r=>eur(r.pipeline.weighted_open_value),sortVal:r=>r.pipeline.weighted_open_value},
    {key:'quality',label:'Qualität',num:true,render:r=>`${r.data_quality.score}/100`,sortVal:r=>r.data_quality.score},
  ],snaps,{sortKey:'month',sortDir:-1});
}
function darkGridY(){return {grid:{color:'rgba(255,255,255,.06)',drawBorder:false},ticks:{color:'#8a8f98',callback:euroTick},border:{display:false}}}
function darkGridX(){return {grid:{display:false},ticks:{color:'#8a8f98'},border:{display:false}}}

// ===========================================================================
//  RENDER — MITARBEITER
// ===========================================================================
function renderMitarbeiter(){
  const tx = txFiltered();
  // Zielerreichung 2025 (fix auf 2025, da Ziel = Jahresziel 2025)
  const tx25 = DB.tx.filter(t=>t.jahr==='2025');
  const um25 = sumBy(tx25, t=>t.vertriebsmitarbeiter, t=>t.gesamt_eur);
  const maList = DB.ma.filter(m=>m.zielvereinbarung_2025_eur>0);
  makeChart('c-ma-ziel', {
    type:'bar',
    data:{ labels:maList.map(m=>m.name.split(' ')[0]+' '+m.name.split(' ')[1][0]+'.'),
      datasets:[
        { label:'Umsatz 2025 (Stichprobe)', data:maList.map(m=>um25.get(m.ma_id)||0), backgroundColor:'#4361ee', borderRadius:6 },
        { label:'Jahresziel', data:maList.map(m=>m.zielvereinbarung_2025_eur), backgroundColor:'rgba(124,58,237,.18)', borderRadius:6 },
      ]},
    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{position:'top',align:'end'}, tooltip:{callbacks:{label:c=>` ${c.dataset.label}: ${eur(c.parsed.x)}`}}},
      scales:{ x:{...gridY()}, y:gridX() } }
  });

  // win rate per MA
  const stats={};
  DB.opps.forEach(o=>{ const s=stats[o.maname]||(stats[o.maname]={w:0,l:0}); if(o.stage==='Won')s.w++; else if(o.stage==='Lost')s.l++; });
  const names=Object.keys(stats);
  makeChart('c-ma-win', {
    type:'bar',
    data:{ labels:names.map(shortName), datasets:[
      { label:'Gewonnen', data:names.map(n=>stats[n].w), backgroundColor:'#10b981', borderRadius:6, stack:'s' },
      { label:'Verloren', data:names.map(n=>stats[n].l), backgroundColor:'#ef4444', borderRadius:6, stack:'s' },
    ]},
    options:{ responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{position:'top',align:'end'},
        tooltip:{callbacks:{afterBody:items=>{ const n=names[items[0].dataIndex]; const s=stats[n]; const t=s.w+s.l; return 'Win-Rate: '+(t?pct(s.w/t*100):'–'); }}}},
      scales:{ y:{...gridX(), grid:{color:'#eef1f7'}, ticks:{precision:0}}, x:gridX() } }
  });

  // ranking table
  const um   = sumBy(tx, t=>t.vertriebsmitarbeiter, t=>t.gesamt_eur);
  const mg   = sumBy(tx, t=>t.vertriebsmitarbeiter, t=>t.marge_eur);
  const cnt  = countBy(tx, t=>t.vertriebsmitarbeiter);
  const maxUm = Math.max(1, ...[...um.values()]);
  const rows = DB.ma.map(m=>{
    const u=um.get(m.ma_id)||0, g=mg.get(m.ma_id)||0, c=cnt.get(m.ma_id)||0;
    const s=stats[m.name]||{w:0,l:0}; const dec=s.w+s.l;
    return { name:m.name, rolle:m.rolle, umsatz:u, marge:g, mp:u?g/u*100:0, n:c,
      avg:c?u/c:0, wr:dec?s.w/dec*100:null, bar:u/maxUm };
  }).filter(r=>r.umsatz>0 || r.n>0);

  renderTable('t-ma', [
    {key:'name', label:'Mitarbeiter', render:r=>`<strong>${r.name}</strong><div style="color:var(--ink-faint);font-size:11px">${r.rolle}</div>`},
    {key:'umsatz', label:'Umsatz', num:true, render:r=>`<div class="bar-cell"><span>${eur(r.umsatz)}</span><span class="track"><span class="fill" style="width:${(r.bar*100).toFixed(0)}%"></span></span></div>`, sortVal:r=>r.umsatz},
    {key:'marge', label:'Marge', num:true, render:r=>eur(r.marge), sortVal:r=>r.marge},
    {key:'mp', label:'Marge %', num:true, render:r=>pct(r.mp), sortVal:r=>r.mp},
    {key:'n', label:'Aufträge', num:true, render:r=>num(r.n), sortVal:r=>r.n},
    {key:'avg', label:'Ø Wert', num:true, render:r=>eur(r.avg), sortVal:r=>r.avg},
    {key:'wr', label:'Win-Rate', num:true, render:r=> r.wr==null?'<span class="pill neutral">–</span>': `<span class="pill ${r.wr<15?'bad':r.wr<30?'warn':'ok'}">${r.wr.toFixed(0)} %</span>`, sortVal:r=>r.wr??-1},
  ], rows, {sortKey:'umsatz', sortDir:-1});
}
const shortName = n => { const p=String(n).split(' '); return p.length>1?p[0]+' '+p[1][0]+'.':n; };

// ===========================================================================
//  RENDER — AUFTRÄGE
// ===========================================================================
let auftraegeRows=[];
function renderAuftraege(){
  const tx = txFiltered();
  const umsatz=tx.reduce((s,t)=>s+t.gesamt_eur,0);
  const marge=tx.reduce((s,t)=>s+t.marge_eur,0);
  const rab=tx.length?tx.reduce((s,t)=>s+(t.rabatt_prozent||0),0)/tx.length:0;
  document.getElementById('kpi-auftraege').innerHTML=[
    {cls:'g2',label:'Transaktionen',value:num(tx.length),foot:scopeLabel()},
    {cls:'g1',label:'Umsatz',value:eur(umsatz),foot:'gefiltert'},
    {cls:'g3',label:'Ø Auftragswert',value:eur(tx.length?umsatz/tx.length:0),foot:'je Transaktion'},
    {cls:'g4',label:'Ø Rabatt',value:pct(rab),foot:'gewährt'},
  ].map(kpiHTML).join('');

  auftraegeRows = tx.slice();
  document.getElementById('auftraege-count').textContent = num(tx.length)+' Transaktionen im Filter';
  drawAuftraege(document.getElementById('search-auftraege').value);
}
function drawAuftraege(q){
  q=(q||'').toLowerCase().trim();
  let rows=auftraegeRows;
  if(q) rows=rows.filter(t=>(t.transaktion_id+' '+t.kname+' '+t.modell+' '+t.land+' '+t.maname+' '+t.vertriebskanal).toLowerCase().includes(q));
  renderTable('t-auftraege', [
    {key:'datum',label:'Datum',render:r=>r.datum,sortVal:r=>r.datum},
    {key:'transaktion_id',label:'ID',render:r=>r.transaktion_id,sortVal:r=>r.transaktion_id},
    {key:'kname',label:'Kunde',render:r=>r.kname,sortVal:r=>r.kname},
    {key:'modell',label:'Modell',render:r=>r.modell,sortVal:r=>r.modell},
    {key:'vertriebskanal',label:'Kanal',render:r=>`<span class="pill neutral">${r.vertriebskanal}</span>`,sortVal:r=>r.vertriebskanal},
    {key:'land',label:'Land',render:r=>r.land,sortVal:r=>r.land},
    {key:'menge',label:'Menge',num:true,render:r=>num(r.menge),sortVal:r=>r.menge},
    {key:'gesamt_eur',label:'Umsatz',num:true,render:r=>eur(r.gesamt_eur),sortVal:r=>r.gesamt_eur},
    {key:'marge_eur',label:'Marge',num:true,render:r=>eur(r.marge_eur),sortVal:r=>r.marge_eur},
    {key:'rabatt_prozent',label:'Rabatt',num:true,render:r=>pct(r.rabatt_prozent||0),sortVal:r=>r.rabatt_prozent||0},
  ], rows, {sortKey:'datum', sortDir:-1, limit:400});
}

// ===========================================================================
//  RENDER — KUNDEN
// ===========================================================================
let kundenRows=[];
function renderKunden(){
  const tx = txFiltered();
  const kf = kundenFiltered();
  const umByK = sumBy(tx, t=>t.kunde_id, t=>t.gesamt_eur);

  // top 10 by umsatz
  const top = [...umByK.entries()].map(([id,u])=>({name:(DB.kById[id]||{}).name||id, u})).sort((a,b)=>b.u-a.u).slice(0,10).reverse();
  makeChart('c-top-kunden', {
    type:'bar',
    data:{ labels:top.map(t=>t.name.length>22?t.name.slice(0,21)+'…':t.name),
      datasets:[{ label:'Umsatz', data:top.map(t=>t.u), backgroundColor:'#4361ee', borderRadius:6 }]},
    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{display:false}, tooltip:{callbacks:{label:c=>' '+eur(c.parsed.x)}}},
      scales:{ x:gridY(), y:gridX() } }
  });

  // segment distribution (count of customers)
  const seg = mapToSorted(countBy(kf, k=>k.kundensegment));
  makeChart('c-kunden-segment', {
    type:'doughnut',
    data:{ labels:seg.map(s=>s[0]), datasets:[{ data:seg.map(s=>s[1]), backgroundColor:PALETTE, borderWidth:2, borderColor:'#fff', hoverOffset:6 }]},
    options:{ responsive:true, maintainAspectRatio:false, cutout:'62%',
      plugins:{ legend:{position:'right'}, tooltip:{callbacks:{label:c=>` ${c.label}: ${num(c.parsed)} Kunden`}}} }
  });

  // table
  const maxDate = MAXDATE;
  kundenRows = kf.map(k=>{
    const u = umByK.get(k.kunde_id)||0;
    const inactive = monthsBetween(k.letzter_kauf, maxDate) > 6;
    return {...k, umsatz:u, inactive};
  });
  drawKunden(document.getElementById('search-kunden').value);
}
function drawKunden(q){
  q=(q||'').toLowerCase().trim();
  let rows=kundenRows;
  if(q) rows=rows.filter(k=>(k.name+' '+k.stadt+' '+k.land+' '+k.kundensegment+' '+k.kunde_id).toLowerCase().includes(q));
  renderTable('t-kunden', [
    {key:'name',label:'Kunde',render:r=>`<strong>${r.name}</strong>`,sortVal:r=>r.name},
    {key:'typ',label:'Typ',render:r=>`<span class="pill ${r.typ.toLowerCase()}">${r.typ}</span>`,sortVal:r=>r.typ},
    {key:'land',label:'Land',render:r=>r.land,sortVal:r=>r.land},
    {key:'stadt',label:'Stadt',render:r=>r.stadt,sortVal:r=>r.stadt},
    {key:'kundensegment',label:'Segment',render:r=>`<span class="pill neutral">${r.kundensegment}</span>`,sortVal:r=>r.kundensegment},
    {key:'umsatz',label:'Umsatz (Filter)',num:true,render:r=>eur(r.umsatz),sortVal:r=>r.umsatz},
    {key:'lifetime_value_eur',label:'Lifetime Value',num:true,render:r=>eur(r.lifetime_value_eur),sortVal:r=>r.lifetime_value_eur},
    {key:'anzahl_kaeufe',label:'Käufe',num:true,render:r=>num(r.anzahl_kaeufe),sortVal:r=>r.anzahl_kaeufe},
    {key:'letzter_kauf',label:'Letzter Kauf',render:r=>`${r.letzter_kauf}${r.inactive?' <span class="pill bad">inaktiv</span>':''}`,sortVal:r=>r.letzter_kauf},
  ], rows, {sortKey:'lifetime_value_eur', sortDir:-1, limit:300});
}

// ===========================================================================
//  RENDER — PIPELINE
// ===========================================================================
const OPEN_STAGES=['Lead','Qualified','Proposal','Negotiation'];
function renderPipeline(){
  const opps = oppsFiltered();
  const open = opps.filter(o=>OPEN_STAGES.includes(o.stage));
  const openVal = open.reduce((s,o)=>s+o.erwarteter_wert_eur,0);
  const weighted = open.reduce((s,o)=>s+o.erwarteter_wert_eur*(o.abschluss_wahrscheinlichkeit_prozent||0)/100,0);
  const won=opps.filter(o=>o.stage==='Won').length, lost=opps.filter(o=>o.stage==='Lost').length;
  const wr = (won+lost)?won/(won+lost)*100:0;

  document.getElementById('kpi-pipeline').innerHTML=[
    {cls:'g1',label:'Offener Pipeline-Wert',value:eur(openVal),foot:num(open.length)+' offene Chancen'},
    {cls:'g2',label:'Gewichteter Forecast',value:eur(weighted),foot:'nach Wahrscheinlichkeit'},
    {cls:'g3',label:'Win-Rate',value:pct(wr),foot:`${won} gewonnen · ${lost} verloren`},
    {cls:'g4',label:'Ø Dealgröße',value:eur(open.length?openVal/open.length:0),foot:'offene Chancen'},
  ].map(kpiHTML).join('');

  // stage funnel (incl. all stages by value)
  const order=['Lead','Qualified','Proposal','Negotiation','Won','Lost'];
  const valByStage=sumBy(opps, o=>o.stage, o=>o.erwarteter_wert_eur);
  const cntByStage=countBy(opps, o=>o.stage);
  makeChart('c-pipe-stage', {
    type:'bar',
    data:{ labels:order, datasets:[{ label:'Wert', data:order.map(s=>valByStage.get(s)||0),
      backgroundColor:['#94a3b8','#60a5fa','#4361ee','#7c3aed','#10b981','#ef4444'], borderRadius:8, maxBarThickness:60 }]},
    options:{ responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{display:false}, tooltip:{callbacks:{label:c=>` ${eur(c.parsed.y)} · ${cntByStage.get(order[c.dataIndex])||0} Opps`}}},
      scales:{ y:gridY(), x:gridX() } }
  });

  // loss reasons
  const lr = mapToSorted(countBy(opps.filter(o=>o.stage==='Lost'&&o.verlustgrund), o=>o.verlustgrund));
  makeChart('c-pipe-lost', {
    type:'bar',
    data:{ labels:lr.map(l=>l[0]), datasets:[{ label:'Anzahl', data:lr.map(l=>l[1]), backgroundColor:'#ef4444', borderRadius:6 }]},
    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{display:false} },
      scales:{ x:{...gridX(), grid:{color:'#eef1f7'}, ticks:{precision:0}}, y:gridX() } }
  });

  // open opps table
  const rows = open.map(o=>({...o, weighted:o.erwarteter_wert_eur*(o.abschluss_wahrscheinlichkeit_prozent||0)/100}));
  renderTable('t-pipe', [
    {key:'opp_id',label:'ID',render:r=>r.opp_id,sortVal:r=>r.opp_id},
    {key:'kname',label:'Kunde',render:r=>r.kname,sortVal:r=>r.kname},
    {key:'modell',label:'Modell',render:r=>r.modell,sortVal:r=>r.modell},
    {key:'stage',label:'Stage',render:r=>`<span class="pill ${stagePill(r.stage)}">${r.stage}</span>`,sortVal:r=>OPEN_STAGES.indexOf(r.stage)},
    {key:'erwarteter_wert_eur',label:'Wert',num:true,render:r=>eur(r.erwarteter_wert_eur),sortVal:r=>r.erwarteter_wert_eur},
    {key:'abschluss_wahrscheinlichkeit_prozent',label:'Wahrsch.',num:true,render:r=>pct(r.abschluss_wahrscheinlichkeit_prozent),sortVal:r=>r.abschluss_wahrscheinlichkeit_prozent},
    {key:'weighted',label:'Gewichtet',num:true,render:r=>eur(r.weighted),sortVal:r=>r.weighted},
    {key:'maname',label:'Mitarbeiter',render:r=>shortName(r.maname),sortVal:r=>r.maname},
    {key:'letzte_aktivitaet',label:'Letzte Aktivität',render:r=>r.letzte_aktivitaet,sortVal:r=>r.letzte_aktivitaet},
  ], rows, {sortKey:'weighted', sortDir:-1});
}
function stagePill(s){ return s==='Negotiation'?'warn':s==='Proposal'?'b2b':s==='Qualified'?'b2c':'neutral'; }

// ===========================================================================
//  Generic sortable table
// ===========================================================================
function renderTable(id, cols, rows, opts){
  opts=opts||{};
  const el=document.getElementById(id);
  const state=el._sort || {key:opts.sortKey, dir:opts.sortDir||-1};
  el._sort=state; el._cols=cols; el._rows=rows; el._opts=opts;

  const sorted=rows.slice().sort((a,b)=>{
    const col=cols.find(c=>c.key===state.key); if(!col) return 0;
    const va=col.sortVal?col.sortVal(a):a[state.key], vb=col.sortVal?col.sortVal(b):b[state.key];
    if(va<vb) return -state.dir; if(va>vb) return state.dir; return 0;
  });
  const limited = opts.limit ? sorted.slice(0,opts.limit) : sorted;

  const thead=`<thead><tr>${cols.map(c=>{
    const arrow=state.key===c.key?(state.dir>0?' ▲':' ▼'):'';
    return `<th class="${c.num?'num':''}" data-key="${c.key}">${c.label}${arrow}</th>`;
  }).join('')}</tr></thead>`;
  const tbody=`<tbody>${limited.map(r=>`<tr>${cols.map(c=>`<td class="${c.num?'num':''}">${c.render?c.render(r):(r[c.key]??'')}</td>`).join('')}</tr>`).join('')}</tbody>`;
  el.innerHTML=thead+tbody;
  if(opts.limit && sorted.length>opts.limit){
    el.insertAdjacentHTML('afterend','');
  }

  el.querySelectorAll('th').forEach(th=>th.onclick=()=>{
    const k=th.dataset.key;
    if(state.key===k) state.dir=-state.dir; else { state.key=k; state.dir=-1; }
    renderTable(id, el._cols, el._rows, el._opts);
  });
}

// ---------- date helper ----------
function monthsBetween(d1, d2){
  if(!d1||!d2) return 999;
  const a=new Date(d1), b=new Date(d2);
  return (b.getFullYear()-a.getFullYear())*12 + (b.getMonth()-a.getMonth());
}

// ===========================================================================
//  Filters & tabs wiring
// ===========================================================================
function fillFilters(){
  const setOpts=(id, vals, allLabel)=>{
    const sel=document.getElementById(id);
    sel.innerHTML=`<option value="">${allLabel}</option>`+vals.map(v=>`<option value="${v.val}">${v.label}</option>`).join('');
    sel.value=FILTERS[id.replace('f-','')]||'';
  };
  const years=[...new Set(DB.tx.map(t=>t.jahr))].sort();
  setOpts('f-jahr', years.map(y=>({val:y,label:y})), 'Alle Jahre');
  setOpts('f-kanal', [...new Set(DB.tx.map(t=>t.vertriebskanal))].sort().map(v=>({val:v,label:v})), 'Alle Kanäle');
  setOpts('f-land', [...new Set(DB.kunden.map(k=>k.land))].sort().map(v=>({val:v,label:v})), 'Alle Länder');
  setOpts('f-ma', DB.ma.map(m=>({val:m.ma_id,label:m.name})), 'Alle Mitarbeiter');
  setOpts('f-modell', DB.produkte.map(p=>({val:p.produkt_id,label:p.modellname})), 'Alle Modelle');
  setOpts('f-segment', [...new Set(DB.kunden.map(k=>k.kundensegment))].sort().map(v=>({val:v,label:v})), 'Alle Segmente');
  setOpts('f-typ', [...new Set(DB.kunden.map(k=>k.typ))].sort().map(v=>({val:v,label:v})), 'Alle Typen');

  ['f-jahr','f-kanal','f-land','f-ma','f-modell','f-segment','f-typ'].forEach(id=>{
    document.getElementById(id).onchange=e=>{ FILTERS[id.replace('f-','')]=e.target.value; renderActive(); };
  });
}

// ---------- Monatsauswahl (oben rechts) ----------
const MONTH_NAMES=['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'];
function monthLabel(id){
  if(!id) return 'Aktueller Stand';
  const [y,m]=id.split('-');
  return (MONTH_NAMES[parseInt(m,10)-1]||m)+' '+y;
}
function fillMonthSelect(){
  const sel=document.getElementById('month-select');
  if(!sel) return;
  // Altmodus (Dateien direkt in data/): Auswahl ausblenden
  if(MONTHS.length===1 && MONTHS[0]===''){ sel.style.display='none'; return; }
  sel.style.display='';
  sel.innerHTML=MONTHS.map(m=>`<option value="${m}">${monthLabel(m)}</option>`).join('');
  sel.value=CURRENT_MONTH;
  sel.onchange=e=>{ CURRENT_MONTH=e.target.value; refresh(); };
}

const TAB_RENDER={ overview:renderOverview, monatsanalyse:renderMonatsanalyse, mitarbeiter:renderMitarbeiter, auftraege:renderAuftraege, kunden:renderKunden, pipeline:renderPipeline };
let activeTab='overview';
function renderActive(){ TAB_RENDER[activeTab](); }
function renderAllNeeded(){ renderActive(); }

function wireTabs(){
  document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>{
    document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));
    t.classList.add('active');
    activeTab=t.dataset.tab;
    document.querySelectorAll('.tab-panel').forEach(p=>p.classList.add('hidden'));
    document.getElementById('tab-'+activeTab).classList.remove('hidden');
    renderActive();
  });
  document.getElementById('search-auftraege').oninput=e=>drawAuftraege(e.target.value);
  document.getElementById('search-kunden').oninput=e=>drawKunden(e.target.value);
  document.getElementById('btn-reset').onclick=()=>{ FILTERS=defaultFilters(); fillFilters(); renderActive(); toast('Filter zurückgesetzt'); };
  document.getElementById('btn-export').onclick=exportCSV;
  document.getElementById('btn-refresh').onclick=refresh;
}

// ---------- export ----------
function exportCSV(){
  const tx=txFiltered();
  const cols=['transaktion_id','datum','kunde_id','kname','produkt_id','modell','menge','einzelpreis_eur','gesamt_eur','marge_eur','vertriebskanal','rabatt_prozent','land','segment','ktyp','vertriebsmitarbeiter','maname'];
  const head=cols.join(';');
  const body=tx.map(t=>cols.map(c=>{ let v=t[c]??''; if(typeof v==='string'&&v.includes(';')) v='"'+v+'"'; return v; }).join(';')).join('\n');
  const blob=new Blob(['﻿'+head+'\n'+body],{type:'text/csv;charset=utf-8;'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download='velomax_transaktionen'+(CURRENT_MONTH?'_'+CURRENT_MONTH:'')+'.csv';
  a.click();
  toast(num(tx.length)+' Transaktionen exportiert');
}

// ---------- refresh ----------
async function refresh(){
  const btn=document.getElementById('btn-refresh');
  btn.classList.add('refreshing');
  try{
    await loadAll();          // entdeckt dabei auch neue Monatsordner
    fillMonthSelect();
    fillFilters();
    renderActive();
    setDatenstand();
    toast('Daten aktualisiert · '+monthLabel(CURRENT_MONTH)+' · letzte Transaktion '+MAXDATE);
  }catch(e){ showError(e); }
  finally{ btn.classList.remove('refreshing'); }
}

// ---------- chrome ----------
function setDatenstand(){
  const src = DATA_LIVE
    ? 'Quelle: <code>./data</code> &mdash; <span style="color:#15803d;font-weight:700">live</span> aus dem CRM-Ordner.'
    : 'Quelle: <code>./data_snapshot</code> &mdash; <span style="color:#b45309;font-weight:700">Momentaufnahme</span> (Live-Zugriff blockiert).';
  const mon = CURRENT_MONTH ? `Datenstand: <strong>${monthLabel(CURRENT_MONTH)}</strong> (Ordner <code>${CURRENT_MONTH}</code>).<br>` : '';
  document.getElementById('datenstand').innerHTML=
    mon+
    `${num(DB.tx.length)} Transaktionen · ${num(DB.kunden.length)} Kunden · ${num(DB.opps.length)} Opportunities.<br>`+
    `Letzte Transaktion: <strong>${MAXDATE}</strong>.<br>${src}`;
  document.getElementById('brand-sub').textContent='Premium-Rennrad · Sales Controlling · '+
    (CURRENT_MONTH ? monthLabel(CURRENT_MONTH) : 'Stand '+MAXDATE);
}
let toastT;
function toast(msg){
  const el=document.getElementById('toast'); el.textContent=msg; el.classList.add('show');
  clearTimeout(toastT); toastT=setTimeout(()=>el.classList.remove('show'),2600);
}
function showError(e){
  console.error(e);
  document.getElementById('overlay').innerHTML=`<div class="err">
    <h2>Daten konnten nicht geladen werden</h2>
    <p>${e.message}</p>
    <p>Dieses Dashboard muss über einen <strong>lokalen Server</strong> laufen (nicht per Doppelklick als <code>file://</code>), damit die CSV-Dateien geladen werden dürfen.</p>
    <p>Starte es mit <code>start.command</code> im Dashboard-Ordner — oder im Terminal:</p>
    <p><code>cd "$(dirname Dashboard)" &amp;&amp; python3 -m http.server 8765</code><br>dann <code>http://localhost:8765</code> öffnen.</p>
  </div>`;
  document.getElementById('overlay').style.display='grid';
}

// ---------- boot ----------
(async function init(){
  try{
    wireTabs();
    await loadAll();
    fillMonthSelect();
    fillFilters();
    setDatenstand();
    renderActive();
    document.getElementById('overlay').style.display='none';
  }catch(e){ showError(e); }
})();
