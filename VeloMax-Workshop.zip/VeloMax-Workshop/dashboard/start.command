#!/bin/bash
# VeloMax CRM Dashboard – Starter
# Doppelklick startet einen lokalen Server und öffnet das Dashboard im Browser.
cd "$(dirname "$0")" || exit 1

# Momentaufnahme der Live-Daten auffrischen (Fallback für Umgebungen ohne Symlink-Zugriff)
# Kopiert die komplette Struktur inkl. Monatsordner (JJJJ-MM).
if [ -d data ] && [ -n "$(ls data 2>/dev/null)" ]; then
  rm -rf data_snapshot
  mkdir -p data_snapshot
  cp -R data/. data_snapshot/ 2>/dev/null && echo "Momentaufnahme aktualisiert."
fi

# Deterministische Agentenanalyse für alle vollständigen Monatsstände erzeugen.
python3 scripts/build_monthly_analysis.py --source data_snapshot --output analysis || exit 1

PORT=8765
# Falls Port belegt: nächsten freien suchen
while lsof -i :$PORT >/dev/null 2>&1; do PORT=$((PORT+1)); done

echo "──────────────────────────────────────────────"
echo "  VeloMax CRM Dashboard"
echo "  Server: http://localhost:$PORT"
echo "  Zum Beenden dieses Fenster schließen (oder Strg+C)."
echo "──────────────────────────────────────────────"

# Browser nach kurzer Verzögerung öffnen
( sleep 1; open "http://localhost:$PORT/index.html" ) &

# Server starten (folgt dem data-Symlink zum CRM-Ordner)
python3 -m http.server $PORT
