import json
import subprocess
import tempfile
import unittest
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
SCRIPT = PROJECT / "scripts" / "build_monthly_analysis.py"
SOURCE = PROJECT / "data_snapshot"


class MonthlyAnalysisTests(unittest.TestCase):
    def test_builds_index_and_one_analysis_per_complete_month(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            result = subprocess.run(
                ["python3", str(SCRIPT), "--source", str(SOURCE), "--output", str(out)],
                text=True,
                capture_output=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            index = json.loads((out / "index.json").read_text(encoding="utf-8"))
            self.assertEqual(index["months"], ["2026-01", "2026-02", "2026-03", "2026-04", "2026-05", "2026-06"])
            self.assertEqual(index["latest_month"], "2026-06")
            self.assertEqual(len(index["snapshots"]), 6)
            latest = json.loads((out / "2026-06.json").read_text(encoding="utf-8"))
            self.assertIn(latest["status"], {"ready", "ready_with_warnings"})
            self.assertEqual(latest["row_counts"]["customers"], 150)
            self.assertGreater(latest["sales_total"]["revenue"], 0)
            self.assertIn("pipeline", latest)
            self.assertIn("data_quality", latest)
            self.assertIn("management_analysis", latest)

    def test_snapshot_deltas_use_cumulative_ledger_without_double_counting(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            subprocess.run(["python3", str(SCRIPT), "--source", str(SOURCE), "--output", str(out)], check=True)
            index = json.loads((out / "index.json").read_text(encoding="utf-8"))
            snapshots = {x["month"]: x for x in index["snapshots"]}
            self.assertEqual(snapshots["2026-01"]["snapshot_delta"]["transactions"], snapshots["2026-01"]["sales_total"]["transactions"])
            self.assertEqual(
                snapshots["2026-06"]["snapshot_delta"]["transactions"],
                snapshots["2026-06"]["sales_total"]["transactions"] - snapshots["2026-05"]["sales_total"]["transactions"],
            )
            self.assertAlmostEqual(
                snapshots["2026-06"]["snapshot_delta"]["revenue"],
                snapshots["2026-06"]["sales_total"]["revenue"] - snapshots["2026-05"]["sales_total"]["revenue"],
                places=2,
            )

    def test_missing_required_file_marks_month_blocked_but_keeps_index(self):
        with tempfile.TemporaryDirectory() as src_tmp, tempfile.TemporaryDirectory() as out_tmp:
            src = Path(src_tmp)
            month = src / "2026-01"
            month.mkdir()
            (month / "kunden.csv").write_text("kunde_id\nK-1\n", encoding="utf-8")
            result = subprocess.run(
                ["python3", str(SCRIPT), "--source", str(src), "--output", str(out_tmp)],
                text=True,
                capture_output=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            analysis = json.loads((Path(out_tmp) / "2026-01.json").read_text(encoding="utf-8"))
            self.assertEqual(analysis["status"], "blocked")
            self.assertTrue(analysis["hard_errors"])


if __name__ == "__main__":
    unittest.main()
