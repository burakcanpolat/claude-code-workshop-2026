# VeloMax CRM Dashboard, Windows starter
# Double click, or right click and choose "Run with PowerShell".
# Rebuilds the analysis (if Python is available), starts a local server, and opens the browser.

$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

function Get-PythonCommand {
    foreach ($name in @("python", "python3", "py")) {
        $cmd = Get-Command $name -ErrorAction SilentlyContinue
        if ($cmd) { return $cmd.Source }
    }
    return $null
}

$python = Get-PythonCommand

if (-not $python) {
    Write-Host "----------------------------------------------------------------"
    Write-Host " Python was not found on this machine."
    Write-Host " The dashboard view needs Python to rebuild the analysis and"
    Write-Host " serve the page locally, so it will not start."
    Write-Host " Every other exercise in the kit still works without Python:"
    Write-Host " Claude can read the CSV files directly and write the report."
    Write-Host "----------------------------------------------------------------"
    exit 0
}

Write-Host "Rebuilding the monthly analysis..."
& $python "scripts\build_monthly_analysis.py" --source "data_snapshot" --output "analysis"
if ($LASTEXITCODE -ne 0) {
    Write-Host "The analysis build failed. Check the message above."
    exit 1
}

function Test-PortFree {
    param([int]$Port)
    $inUse = Get-NetTCPConnection -LocalPort $Port -ErrorAction SilentlyContinue
    return (-not $inUse)
}

$port = 8765
while (-not (Test-PortFree -Port $port)) {
    $port++
}

Write-Host "----------------------------------------------------------------"
Write-Host "  VeloMax CRM Dashboard"
Write-Host "  Server: http://localhost:$port"
Write-Host "  Close this window (or press Ctrl+C) to stop it."
Write-Host "----------------------------------------------------------------"

Start-Job -ScriptBlock {
    param($url)
    Start-Sleep -Seconds 1
    Start-Process $url
} -ArgumentList "http://localhost:$port/index.html" | Out-Null

& $python -m http.server $port
