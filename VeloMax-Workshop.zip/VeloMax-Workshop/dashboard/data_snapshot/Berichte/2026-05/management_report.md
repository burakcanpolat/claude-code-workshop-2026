# CRM- und Vertriebsreport – Snapshot 2026-05

**Status:** `ready_with_warnings`  
**Datenordner:** `/Users/basarseven/Library/CloudStorage/GoogleDrive-basarseven@googlemail.com/Meine Ablage/CRM Daten/2026-05`  
**Buchungszeitraum:** 2024-01-02 bis 2025-10-28  
**Letzter gebuchter Monat:** 2025-10

## Management Summary
- **Fakt:** Gesamtumsatz im verfügbaren Ledger: **5.431.407,72 €**, Marge **1.382.921,12 €** (25,5 %).
- **Fakt:** Im letzten gebuchten Monat 2025-10: **232.765,15 € Umsatz**, **75 Einheiten**, **59.757,64 € Marge**.
- **Fakt:** Gegenüber 2025-09: Umsatz **-8,8 %**, Marge **-10,9 %**, Einheiten **-7,4 %**.
- **Fakt:** Offene Pipeline: **33 Opportunities / 760.056,54 €**, wahrscheinlichkeitsgewichtet **284.457,63 €**.
- **Inference:** Die höchste kurzfristige Managementpriorität ist die Bereinigung der Daten- und Pipelinewarnungen; erst danach sind Forecast- und Zielaussagen belastbar.

## Datenqualität
- Keine harten Struktur- oder Referenzfehler erkannt.

### Warnungen
- Snapshot 2026-05, aber letztes Ereignisdatum ist 2025-12-15; der Ordner scheint ein historischer/kumulativer Datenstand zu sein.
- 17 Kunden haben Erstkauf nach letztem Kauf.
- Kundenstamm vs. Ledger: 23 Abweichungen bei Kaufanzahl, 23 beim LTV.
- 23 Opportunities haben einen anderen Verantwortlichen als der Kundenstamm.
- 24 von 33 offenen Opportunities sind zum Snapshot-Ende länger als 180 Tage ohne Aktivität.

## Vertrieb nach Kanal
| Kanal | Umsatz | Marge | Marge % | Einheiten |
|---|---:|---:|---:|---:|
| Grosshandel | 3.457.202,62 € | 762.719,22 € | 22,1 % | 1497 |
| Webshop | 1.974.205,10 € | 620.201,90 € | 31,4 % | 359 |

## Produkte
| Produkt | Umsatz | Marge | Marge % | Einheiten |
|---|---:|---:|---:|---:|
| VeloMax Race 700 | 1.298.417,39 € | 339.693,30 € | 26,2 % | 288 |
| VeloMax Allroad 300 | 1.094.539,77 € | 260.233,48 € | 23,8 % | 467 |
| VeloMax Gravel 500 | 1.071.746,92 € | 261.117,22 € | 24,4 % | 367 |
| VeloMax Endurance 100 | 946.055,92 € | 217.523,52 € | 23,0 % | 620 |
| VeloMax Aero 900 | 732.490,10 € | 233.233,00 € | 31,8 % | 82 |
| VeloMax Time Trial Pro | 288.157,62 € | 71.120,60 € | 24,7 % | 32 |

## Top-Kunden
| Kunde | Umsatz | Marge | Transaktionen |
|---|---:|---:|---:|
| Radhaus Den Haag GmbH (`K-B2B-029`) | 518.262,87 € | 112.204,12 € | 16 |
| Pedal Den Haag AG (`K-B2B-007`) | 448.590,87 € | 99.390,42 € | 16 |
| Velo Utrecht AG (`K-B2B-002`) | 231.364,75 € | 51.464,54 € | 16 |
| Tour Den Haag GmbH (`K-B2B-015`) | 213.925,00 € | 46.990,98 € | 15 |
| Cyclo Genf GmbH & Co. KG (`K-B2B-006`) | 200.940,88 € | 44.486,04 € | 11 |
| Pedal Lyon OHG (`K-B2B-026`) | 193.516,04 € | 43.091,14 € | 13 |
| Radwelt Muenster GmbH (`K-B2B-030`) | 172.142,18 € | 37.781,88 € | 13 |
| Rennrad Nuernberg AG (`K-B2B-021`) | 152.798,28 € | 34.337,04 € | 10 |
| Radhaus Rostock GmbH (`K-B2B-023`) | 145.583,48 € | 32.298,12 € | 5 |
| Radwelt Rom OHG (`K-B2B-017`) | 135.056,38 € | 29.754,08 € | 5 |

## Pipeline
- Closed Win Rate nach Anzahl: **65,1 %** (28 Won / 15 Lost).
- Verlustgründe: Preis zu hoch: 6, Lieferzeit zu lang: 3, Falsches Modell: 2, Budget verschoben: 2, Kein Bedarf mehr: 1, Wettbewerber gewonnen: 1.

## Vertriebsverantwortliche
| Verantwortliche Person | Umsatz | Marge | Einheiten |
|---|---:|---:|---:|
| Jonas Petrowski | 2.077.275,46 € | 457.613,08 € | 882 |
| Tobias Reinhardt | 1.974.205,10 € | 620.201,90 € | 359 |
| Carolin Friedrich | 613.368,25 € | 135.615,48 € | 276 |
| Isabelle Moreau | 418.562,35 € | 93.118,78 € | 184 |
| Sabine Vollmer | 196.842,13 € | 43.316,68 € | 81 |
| Markus Hellweg | 151.154,43 € | 33.055,20 € | 74 |

## Sparring: nächste Managementfragen
1. Ist der Ordnername der Snapshot-Zeitpunkt oder sollte er den Buchungsmonat bezeichnen?
2. Sollen offene Opportunities mit mehr als 180 Tagen ohne Aktivität geschlossen, neu bewertet oder aktiv reaktiviert werden?
3. Welche Zieldefinition gilt je Mitarbeiter: gebuchter Umsatz, Opportunity-Wert, Deckungsbeitrag oder Team-/Gebietsumsatz?

## Evidenz- und Unsicherheitspolitik
- **Fakt** = deterministisch aus den genannten Quelldateien berechnet.
- **Inference** = plausible Deutung, keine bewiesene Ursache.
- **Hypothese** = muss mit zusätzlichen Daten oder einem Experiment geprüft werden.
- **Vorschlag** = benötigt menschliche Entscheidung; der Agent führt keine Vertriebsaktion autonom aus.
