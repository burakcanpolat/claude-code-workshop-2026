# Sales Controlling KPIs VeloMax GmbH

Stand: 17.12.2025 (Datenbestand bis Dezember 2025)

Dieses Dokument fasst die wichtigsten Kennzahlen zusammen, die ein Sales Controller aus den vorliegenden Daten ableiten soll. Es dient als Orientierungsraster fuer die Workshop-Uebungen mit ChatGPT und Claude.

## 1. Umsatz und Volumen

| Kennzahl | Berechnung | Datenquelle |
|---|---|---|
| Gesamtumsatz 2025 | Summe `gesamt_eur` fuer Datum 2025 | sales_transactions.csv |
| Gesamtumsatz 2024 | Summe `gesamt_eur` fuer Datum 2024 | sales_transactions.csv |
| Year over Year Wachstum | (Umsatz 2025 / Umsatz 2024) minus 1 | sales_transactions.csv |
| Umsatz pro Vertriebskanal | Gruppierung nach `vertriebskanal` | sales_transactions.csv |
| Umsatzanteil Webshop vs. Grosshandel | Anteil je Kanal am Gesamtumsatz | sales_transactions.csv |
| Saisonindex pro Monat | Monatsumsatz / Durchschnittsmonat | sales_transactions.csv |

## 2. Marge und Profitabilitaet

| Kennzahl | Berechnung | Datenquelle |
|---|---|---|
| Gesamtmarge EUR | Summe `marge_eur` | sales_transactions.csv |
| Margenquote | Marge / Umsatz | sales_transactions.csv |
| Marge pro Modell | Gruppierung `produkt_id` | sales_transactions.csv, produkte.json |
| Marge pro Kanal | Gruppierung `vertriebskanal` | sales_transactions.csv |
| Top 3 margenstaerkste Modelle | Marge pro Modell, absteigend | sales_transactions.csv |
| Rabatt-Effekt | Differenz Listenpreis zu effektivem Einzelpreis | sales_transactions.csv |

## 3. Kunden

| Kennzahl | Berechnung | Datenquelle |
|---|---|---|
| Aktive Kunden | Anzahl mit `status` = aktiv | kunden.csv |
| Customer Lifetime Value | Spalte `lifetime_value_eur` | kunden.csv |
| Top 10 Kunden nach Umsatz | Sortierung `lifetime_value_eur` | kunden.csv |
| Durchschnittlicher Auftragswert | Umsatz / Anzahl Transaktionen | sales_transactions.csv |
| Wiederkaufquote | Anteil Kunden mit mehr als einem Kauf | kunden.csv |
| Kundenstruktur B2B vs. B2C | Verteilung `typ` | kunden.csv |
| Umsatz nach Kundensegment | Gruppierung `kundensegment` | beide |

## 4. Pipeline und Forecast

| Kennzahl | Berechnung | Datenquelle |
|---|---|---|
| Pipeline-Wert offen | Summe `erwarteter_wert_eur` fuer Stages Lead bis Negotiation | opportunities.csv |
| Gewichteter Forecast | Summe (erwarteter_wert mal Wahrscheinlichkeit) | opportunities.csv |
| Win Rate | Won / (Won plus Lost) | opportunities.csv |
| Conversion pro Stage | Uebergangsquote zwischen Stages | opportunities.csv |
| Cycle Time | Tage zwischen `erstellt_datum` und Won/Lost | opportunities.csv |
| Pipeline pro Vertriebsmitarbeiter | Gruppierung `vertriebsmitarbeiter` | opportunities.csv |
| Verlustgrund-Analyse | Top Grund nach Haeufigkeit und Wert | opportunities.csv |

## 5. Vertriebsleistung und Aktivitaet

| Kennzahl | Berechnung | Datenquelle |
|---|---|---|
| Zielerreichung 2025 | Ist-Umsatz / Zielvereinbarung | sales_transactions.csv, vertriebsmitarbeiter.json |
| Aktivitaeten pro MA | Anzahl `aktivitaet_id` | aktivitaeten.csv |
| Conversion Aktivitaet zu Opportunity | Opps / Aktivitaeten je MA | beide |
| Durchschnittliche Aktivitaetsdauer | Mittelwert `dauer_minuten` | aktivitaeten.csv |
| Ergebnisverteilung | Anteil positiv/neutral/negativ | aktivitaeten.csv |

## 6. Regionale Verteilung

| Kennzahl | Berechnung | Datenquelle |
|---|---|---|
| Umsatz pro Land | Gruppierung `land` aus Kundenstamm | beide |
| Wachstum pro Land Year over Year | Vergleich 2024 zu 2025 | beide |
| Top PLZ-Cluster | Aggregation nach `plz` Praefix | beide |

## 7. Produktportfolio

| Kennzahl | Berechnung | Datenquelle |
|---|---|---|
| Absatz pro Modell | Summe `menge` pro Produkt | sales_transactions.csv |
| Kanalmix pro Modell | Webshop vs. Grosshandel je Produkt | sales_transactions.csv |
| Umsatz pro Modell | Summe `gesamt_eur` pro Produkt | sales_transactions.csv |
| Margenbeitrag pro Modell | Marge pro Produkt zur Gesamtmarge | sales_transactions.csv |
| Top Produkt pro Region | Kombination Land plus Produkt | beide |

## Hinweis fuer den Workshop

Diese KPIs sind die uebliche Werkbank fuer einen Sales Controller. Die spannende Frage im Workshop ist nicht, ob KI die Zahlen berechnen kann (das kann sie), sondern welche Auffaelligkeiten sie ohne explizite Anweisung erkennt, welche Hypothesen sie aufstellt und wie sie eine Handlungsempfehlung formuliert. Genau dort entstehen die fuehrungsrelevanten Erkenntnisse.
