# VeloMax GmbH CRM Musterdatensatz

Dieser Datensatz dient als praxisnaher Uebungsfall fuer das Training "Claude Code in der Claude Desktop App". Die Teilnehmer arbeiten mit Claude an typischen Fragestellungen eines Sales Controllers im Premium-Rennradgeschaeft.

## Unternehmenskontext

| Merkmal | Wert |
|---|---|
| Name | VeloMax GmbH |
| Sitz | Bocholt, Nordrhein-Westfalen |
| Gruendung | 2011 |
| Geschaeft | Premium-Rennradhersteller mit 6 Modellen |
| Vertrieb | eigener Webshop und Grosshandelspartner (Fachhandel) |
| Mitarbeiter | 78 |
| Umsatz Geschaeftsjahr 2025 | rund 24,5 Mio. EUR |
| Zielgruppe | ambitionierte Hobby-Rennradfahrer und semi-professionelle Sportler, 30 bis 55 Jahre |

## Dateiuebersicht

| Datei | Inhalt | Format |
|---|---|---|
| produkte.json | 6 Rennrad-Modelle mit Spezifikationen, Preisen und Margen | JSON |
| vertriebsmitarbeiter.json | 8 Vertriebsmitarbeiter mit Rollen und Jahreszielen 2025 | JSON |
| kunden.csv | 150 Kunden (30 B2B Grosshaendler, 120 B2C Endkunden) inklusive Lifetime Value | CSV |
| opportunities.csv | 82 Verkaufschancen der letzten 18 Monate mit Stages und Verlustgruenden | CSV |
| sales_transactions.csv | 612 Transaktionen ueber 24 Monate (Januar 2024 bis Dezember 2025) | CSV |
| aktivitaeten.csv | 200 Vertriebsaktivitaeten (Calls, Meetings, Mailings, Demos, Messen) | CSV |
| kpis_sales_controlling.md | Liste der KPIs, die ein Sales Controller aus dem Datensatz ableitet | Markdown |
| README.md | Dieses Dokument | Markdown |

Datenstand: 17. Dezember 2025. Letzte Transaktion: Dezember 2025.

## Hinweis zum Umsatzvolumen

Der reale Jahresumsatz der VeloMax GmbH 2025 betraegt rund 24,5 Mio. EUR. Dieser CRM-Auszug bildet bewusst nur ein repraesentatives Sample der Transaktionen ab (rund 3,1 Mio. EUR aus 327 Transaktionen in 2025), um die Datenmenge fuer den Workshop handhabbar zu halten. Die Verteilungen (Kanalmix, Modellmix, Saisonalitaet, regionale Anteile) entsprechen jedoch dem Gesamtgeschaeft.

## Referenzielle Konsistenz

Alle Fremdschluessel sind validiert:

- `kunde_id` in opportunities.csv und sales_transactions.csv und aktivitaeten.csv existieren in kunden.csv
- `produkt_id` in opportunities.csv und sales_transactions.csv existieren in produkte.json
- `vertriebsmitarbeiter` (MA_ID) existieren in vertriebsmitarbeiter.json

## Workshop-Analysefragen

Die folgenden Fragen sind als Einstieg fuer die Uebungen mit Claude gedacht. Sie reichen vom einfachen Lookup bis zur strategischen Empfehlung.

1. Wie hat sich der Umsatz pro Vertriebskanal in 2025 gegenueber 2024 entwickelt, und welcher Kanal ist margenstaerker?
2. Welche Kunden gehoeren zu den Top 10 nach Lifetime Value, und welche davon haben in den letzten sechs Monaten keinen Kauf mehr getaetigt?
3. Welche Vertriebsmitarbeiter erreichen ihre Jahresziele 2025, und welche bleiben deutlich zurueck? Erstelle ein Ranking mit Zielerreichungsquote.
4. Welche Modelle performen ueber die beiden Vertriebskanaele unterschiedlich, und welche strategischen Schlussfolgerungen lassen sich daraus ableiten?
5. Welche Verlustgruende dominieren in der Pipeline, und welche Kundensegmente sind davon besonders betroffen?
6. Erstelle eine regionale Wachstumsanalyse: Welches Land waechst am staerksten und welches schrumpft?
7. Welche Pipeline-Werte haben wir aktuell offen, und wie hoch ist der gewichtete Forecast fuer die naechsten drei Monate?

## Stilhinweis

Saemtliche Texte sind auf Deutsch verfasst und vermeiden bewusst Bindestriche, die zwei Satzteile verbinden. Wortbindestriche wie "Custom-GPT", "Year-over-Year" oder "Mid-Segment" bleiben erhalten.
