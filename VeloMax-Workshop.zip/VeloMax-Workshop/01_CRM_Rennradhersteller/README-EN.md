# VeloMax Workshop kit, English one-page guide

This is the practice kit for the "Claude Code in the Claude Desktop app" training. It is one fictional company, VeloMax GmbH, a premium road bike maker, used for every exercise in the session. German column names in the data and a German dashboard interface are intentional, not a mistake: reading real, imperfect, non-English business data with Claude's help is part of what the training teaches. Nothing in this kit is real; VeloMax does not exist.

## What is in each folder

- `01_CRM_Rennradhersteller/` The raw CRM data: six files (customers, opportunities, sales transactions, activities, products, sales representatives) plus a KPI reference document and this README. This is the folder most exercises in Block 1 use.
- `dashboard/` A small local web dashboard that reads the same data and renders it as charts and tables. See `dashboard/README-EN.md` for how to start it on macOS or Windows.
- `_staging/2026-07/` A "new month" data folder used only in the capstone exercise near the end of the day. Leave it alone until you are told to move it.
- `templates/` The starting text for your own `CLAUDE.md` file, a finished example skill (`SKILL.md`), a routine you can copy in as plain text, and a set of starter prompts grouped by role.
- `notes.txt`, `client-email.txt`, `approved-proposal.txt`, `meeting-notes.txt` Small sample files used by specific exercises during the day. You will be told when to open them.

## How to open this kit in Claude Code

1. Open the Claude Desktop app and click the **Code** tab.
2. Start a new session: **Cmd+N** on macOS, **Ctrl+N** on Windows.
3. Set the environment to **Local**.
4. Choose the folder for the exercise you are on. For the first exercises this is `VeloMax-Workshop/01_CRM_Rennradhersteller`; for the capstone near the end of the day it is the `VeloMax-Workshop` root folder, so that Claude can see both the data and the dashboard.
5. Check the mode selector next to the send box. Start exercises in **Manual** mode unless a card tells you otherwise.

## The seven workshop analysis questions

These are the questions a sales controller at a company like VeloMax would actually ask. They are printed in German in the main `README.md` in this folder; here they are in English for reference.

1. How did revenue per sales channel develop in 2025 versus 2024, and which channel has the stronger margin?
2. Which customers are in the top 10 by lifetime value, and which of those have made no purchase in the last six months?
3. Which sales representatives are meeting their 2025 annual targets, and which are falling clearly behind? Build a ranking with a target attainment rate.
4. Which models perform differently across the two sales channels, and what strategic conclusions follow from that?
5. Which loss reasons dominate the pipeline, and which customer segments are most affected?
6. Build a regional growth analysis: which country is growing fastest, and which is shrinking?
7. What open pipeline value do we currently have, and what is the weighted forecast for the next three months?

## One thing to remember all day

The column names in the CSV and JSON files, and every label in the dashboard, are in German. That is deliberate. Ask Claude to translate, explain or work with them directly; you do not need to speak German for any exercise today.
