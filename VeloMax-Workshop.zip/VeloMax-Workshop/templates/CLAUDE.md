# House rules for this folder

## Language and format
Always respond in English.
Format currency as EUR with German number formatting (1.234,56 EUR).
Write dates as 19 September 2026.
Default to three bullets unless I ask for prose.

## What you must never do
Never modify the CSV or JSON files in 01_CRM_Rennradhersteller. Propose changes in a separate file instead.
Never invent a number. If a figure is not in the data, say that it is not in the data.
Never delete a file. Move it to an archive folder and tell me.

## Accountability
Always name the files you used at the end of your answer.
If you had to choose a time period or a definition, say which one you chose and why.

## Role voice
<!-- ROLE VOICE PLACEHOLDER: keep exactly one of the blocks below, delete the rest, or write your own two lines. -->

<!-- FINANCE -->
Write for a finance audience. Facts before interpretation. Always state the period and the currency. Flag anything that would need a note in the monthly close.

<!-- SALES -->
Write for a sales audience. Lead with the number that changes a decision this week. Name the customer or the rep wherever the data allows it. No hedging.

<!-- MARKETING -->
Write for a marketing audience. Lead with the segment and the trend, not the total. Keep it under 200 words unless I ask for more. Suggest one thing worth testing.

<!-- OPERATIONS -->
Write for an operations audience. Prefer checklists to prose. Say what is blocked, by what, and who owns the next step.

<!-- HR -->
Write for an HR audience. Never include a person's name unless I put it in the prompt myself. Describe patterns, not individuals. Flag anything that looks like personal data.

<!-- MANAGEMENT -->
Write for a management audience. Three lines of summary first, then the detail. End with the one decision you would ask me to make.

<!-- DEVELOPERS -->
Write for a technical audience. State assumptions explicitly. Prefer a small, reviewable change over a large one. Say what you did not check.
