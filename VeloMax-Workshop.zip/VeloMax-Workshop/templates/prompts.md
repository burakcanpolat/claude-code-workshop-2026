# Every prompt from the session, in the order we used them

Working With Claude Code, 2026-09-19. The unit numbers are the same ones on screen, in the deck and in the handbook, so "P14" and "unit 2.1" mean the same thing everywhere.

Run these in a folder that contains nothing confidential. Read the diff before you accept anything.

## Unit 1.4. How Claude works: the loop and the tools

**P1**
```
Look through this folder and tell me what is in here, what the main topics are, and what looks out of date or inconsistent. Do not change anything yet.
```

## Unit 1.5. Guardrails: the trust dial and where the data goes

**P2**
```
Add a line at the end of notes.txt that says: reviewed on 19 September.
```

## Unit 1.6. Failing safely

**P3 (the deliberately bad one, run only in Manual, only on a throwaway copy)**
```
Reorganise everything in here, fix all the problems, rename files sensibly and make it all consistent.
```

**P4**
```
In this folder, list every opportunity in opportunities.csv whose status is still open but whose most recent entry in aktivitaeten.csv is older than 90 days. Give me a table with customer, owner, value in EUR and days since last activity. Do not change any file.
```

## Unit 1.7. Writing a good request, and "interview me"

**P5**
```
Improve this email.
```

**P6**
```
Rewrite client-email.txt to be under 120 words, keep the numbers in paragraph 2 exactly as they are, match the tone of approved-proposal.txt, and list what you changed at the end.
```

**P7**
```
Before you start, interview me: ask me the three questions you need answered.
```

## Unit 1.8. Ask the data, then your first write

**P9**
```
From kunden.csv and sales_transactions.csv, give me the top 10 customers by lifetime value who have made no purchase in the last six months. One table: customer, lifetime value in EUR, date of last purchase, months since. Do not change any file.
```

**P10**
```
Using vertriebsmitarbeiter.json, opportunities.csv and sales_transactions.csv, rank the sales representatives by target attainment. Show target, achieved and percentage. Say clearly which period you used and why. Do not change any file.
```

**P11**
```
Write a new file called summary.md in this folder with the three most important numbers from this data set and one sentence saying why each one matters. Under 150 words. Name the files you used.
```

## Unit 1.9. Recap and bridge

**P13**
```
Which files did you open to answer my last question, and which files in this folder did you not open? List both.
```

## Unit 2.1. CLAUDE.md: the standing brief

**P14**
```
Draft a two-paragraph status note for the sales lead about this folder's contents.
```

**P15**
```
Create a file called CLAUDE.md at the top level of this folder, next to notes.txt (not inside templates), containing exactly these four lines and nothing else:
Respond in English, formal tone.
Format currency as EUR with German number formatting (1.234,56 EUR).
Never modify the CSV or JSON files; propose changes in a separate file.
Always name the files you used.
```

## Unit 2.2. Context: what fills the window and how to empty it

**P16**
```
Before we stop: write handoff.md at the top level of this folder, next to CLAUDE.md, with three short sections. What we did today. Where things stand right now, including any file you changed. What the next session should do first. Keep it under 20 lines.
```

**P17**
```
/compact Keep the decisions and the numbers. Drop the file listings and the tool output.
```

## Unit 2.3. Subagents: delegate the reading

**P18**
```
Run two subagents in parallel and do not read the data yourself. Subagent one: compare the six monthly snapshots in dashboard/data_snapshot and report what changed between months, as a short table. Subagent two: from 01_CRM_Rennradhersteller/kunden.csv and sales_transactions.csv, name the three customers whose 2025 purchases dropped most versus 2024, with the numbers. When both are back, give me one answer: each report in its own section, then two sentences on what they have in common. Do not change any file.
```

## Unit 2.4. Models, effort and your usage budget

**P55 (run it once on Sonnet 5, then switch model and run it again on Opus 5)**
```
In two sentences, what is in this folder?
```

## Unit 2.5. Skills: package a procedure

**P19**
```
Create a project skill at .claude/skills/monthly-brief/SKILL.md. Name it monthly-brief. The description must say it is used when writing a monthly management brief from a VeloMax monthly analysis file. The instructions must produce, in this order: a three-line summary, a Facts section with only numbers taken from the file, an Inferences section clearly labelled as interpretation, an Anomalies section listing anything that looks wrong or missing, and a Next steps section with at most three items. All currency in EUR with German number formatting (1.234,56 EUR). Never invent a number that is not in the source file. Show me the file before you save it.
```

**P20, first message**
```
/monthly-brief
```

**P20, second message**
```
Write the monthly management brief for dashboard/analysis/2026-06.json.
```

## Unit 2.6. Plugins: install a bundle

The install is a click path: the plus button beside the prompt box, then Plugins, then Add plugin. This is the equivalent copy block if you prefer typing. Replace `<name>` with the plugin we install in the session.

```
/plugin install <name>@claude-plugins-official
```

## Unit 2.7. Connectors and MCP: plug in the systems you already use

**P21 (trainer only)**
```
Search my inbox for the finance team's emails about this month's CRM data. List their open questions, then draft a reply that answers each one with numbers from dashboard/analysis/2026-06.json. Save the draft, do not send.
```

**P25 (optional, participants, read-only)**
```
Using the connector I just added, list the five most recent items and summarise them in one line each. Do not create, change or send anything.
```

## Unit 2.8. Ultracode: a workflow that decides its own shape

**P26**
```
ultracode: audit the six monthly snapshots in dashboard/data_snapshot from four angles (data quality, sales trend, pipeline risk, sales-rep performance) and write audit.html with one section per angle and a one-page executive summary.
```

## Unit 3.2. Capstone 1: the business as it is today

**P27**
```
Start a local web server for the dashboard folder and open it in the Browser pane.
```

## Unit 3.3. Capstone 2: a new month arrives

**P28**
```
A new month arrived in dashboard/data_snapshot/2026-07. Rebuild the analysis with dashboard/scripts/build_monthly_analysis.py, refresh the dashboard, write dashboard/data_snapshot/Berichte/2026-07/management_report.md in English using the monthly-brief skill, and flag what changed versus June.
```

**P33 (the no-Python variant)**
```
A new month arrived in dashboard/data_snapshot/2026-07. Read the CSV files in that folder directly, compute the same monthly figures that dashboard/analysis/2026-06.json contains, and write dashboard/data_snapshot/Berichte/2026-07/management_report.md in English using the monthly-brief skill. Flag what changed versus June. This will be slower than running the script; that is expected.
```

## Unit 3.4. Capstone 3: make it a routine

**P29**
```
Every Monday at 08:00, check dashboard/data_snapshot for a new month folder. If there is one, rebuild the analysis, write the English management report for that month using the monthly-brief skill, and save an Outlook draft reply to the finance team's latest email with the three-line summary of that report. Do not send anything. If there is no new month folder, do nothing and say so.
```

## Unit 3.5. Capstone 4: publish it

**P30**
```
Publish dashboard/data_snapshot/Berichte/2026-08/management_report.md as an artifact: a single readable page with the numbers as a table, the anomalies section highlighted, and the title "VeloMax monthly report, August 2026".
```

## Unit 3.7. Close

**P32**
```
Delete the routine we created today, and list every file you created or modified in this folder during this session so I can check them.
```

## Starter prompts by role

Each list starts with a read-only prompt. Nothing in the first prompt of any role can change a file.

**Finance, P34**
```
Read every file in this folder and tell me, in five bullets, what financial information is here, what period it covers, and anything that looks internally inconsistent. Do not change anything.
```

**Finance, P35**
```
Compare this month's figures with last month's and write me a short variance note: the five largest movements, each with the absolute and percentage change and one sentence on the likely reason. Only use numbers that are in these files. Write it to variance-note.md.
```

**Finance, P36**
```
Every month, when a new month folder appears here, write the variance note in the same format as variance-note.md and flag anything that would need a comment at the close.
```

**Sales, P37**
```
Look through this pipeline data and tell me which open opportunities have had no activity for more than 60 days, sorted by value. Do not change anything.
```

**Sales, P38**
```
Draft a short follow-up message for each of the top five stale opportunities: two sentences each, referencing the last recorded interaction, in a tone that matches approved-proposal.txt. Save them all in one file called follow-ups.md. Do not send anything.
```

**Sales, P39**
```
Before you start, interview me: ask me the three questions you need answered. Then write my weekly pipeline update for the sales lead.
```

**Marketing, P40**
```
Read the campaign and customer files in this folder and tell me which customer segments are growing and which are shrinking, with the numbers you used. Do not change anything.
```

**Marketing, P41**
```
Write a one-page campaign retro for the most recent campaign in this folder: what we did, what happened, what the numbers say, and one thing to test next. Under 300 words. Save it as retro.md.
```

**Marketing, P42**
```
Turn retro.md into a short internal announcement: three bullets and a headline, for people who did not run the campaign.
```

**Operations, P43**
```
Look through this folder and list every process document you can find, when it was last changed, and which ones contradict each other. Do not change anything.
```

**Operations, P44**
```
Turn meeting-notes.txt into our standard format: decisions, open questions, owners, next steps with dates. Keep every name and number exactly as written. Save it as a new file; do not overwrite the original.
```

**Operations, P45**
```
Every Monday at 08:00, check this folder for notes added last week and produce one combined action list with owners and dates.
```

**HR, P46**
```
Without naming any individual, tell me what kinds of documents are in this folder, what personal data categories they appear to contain, and which of them should not be in a folder like this at all. Do not change anything.
```

**HR, P47**
```
Read the job description in this folder and rewrite it to be under 400 words, in plain language, with the requirements split into essential and desirable. Save it as a new file. Do not change the original.
```

**HR, P48**
```
Compare the two policy documents in this folder and give me a table of every point where they say different things. Do not change either file.
```

**Management, P49**
```
Read everything in this folder and give me three bullets: where this project stands, what is blocked, and what decision you would ask me to make this week. Do not change anything.
```

**Management, P50**
```
Write a one-page status note for the leadership meeting from the material in this folder. Three lines of summary first, then detail, then one decision request. Name your sources at the end.
```

**Management, P51**
```
Before you start, interview me: ask me the three questions you need answered. Then write the note I have to send to the board about this.
```

**Developers, P52 `[dev-only]`**
```
Explore this repository and explain its structure, the main entry points, and where the risky parts are. Do not change anything.
```

**Developers, P53 `[dev-only]`**
```
Start in Plan mode: propose an approach for this change, list the files you would touch, and say what you would not touch. Do not edit anything until I approve the plan.
```

**Developers, P54 `[dev-only]`**
```
Review the changes in the diff pane for bugs, missing error handling and anything that contradicts CLAUDE.md. Report only; do not fix anything yet.
```

---

Retired and deliberately not used: P8, P12, P22, P23, P24, P31. If you have an older copy of this file that contains them, replace it with this one.
