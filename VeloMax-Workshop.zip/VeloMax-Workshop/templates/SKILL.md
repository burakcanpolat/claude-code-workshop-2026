---
name: monthly-brief
description: Use when writing a monthly management brief for VeloMax from a monthly analysis file or from a month folder of CRM data. Use it whenever someone asks for the monthly report, the management summary, the monthly brief, or the month-end commentary. Produces the house format: summary, facts, inferences, anomalies, next steps.
---

# Monthly management brief, VeloMax house format

## When this applies
A month has closed and somebody needs the standing management brief for it. The source is normally `dashboard/analysis/<YYYY-MM>.json`, or the month folder under `dashboard/data_snapshot/<YYYY-MM>/` when no analysis file exists yet.

## Gotchas, read these first
- Never write a number that is not in the source. If a figure is missing, write "not in the source data" and put it in the Anomalies section. Do not estimate.
- The source column names are German. Do not translate them inside tables; translate them only in prose, and keep the German name in brackets the first time.
- If both an analysis file and raw CSVs exist for the month, use the analysis file and say so.
- A month with fewer than 20 transactions is not a trend. Say that in the text rather than drawing a conclusion.
- Compare to the immediately preceding month, and only to that month, unless asked otherwise.

## Output format, in this exact order

### 1. Summary
Exactly three lines. The first line is what happened. The second line is the one number that matters most. The third line is what somebody should do about it.

### 2. Facts
Only numbers that appear in, or are directly computed from, the source. A table with the figure, the value, and the comparison to the previous month as an absolute change and a percentage. Currency as EUR with German number formatting (1.234,56 EUR). Percentages to one decimal place.

### 3. Inferences
Clearly labelled as interpretation, not fact. Each inference starts with "This suggests" or "A plausible reading is". At most four. Every inference names the fact it rests on.

### 4. Anomalies
Anything that looks wrong, missing, stale or internally inconsistent: gaps in dates, values outside a plausible range, records referring to products or people that do not exist in the reference files, a month with no activity for a representative who had transactions. If there are none, write "No anomalies found" and say which checks you ran.

### 5. Next steps
At most three. Each one is a concrete action with an owner role (not a person's name) and a deadline expressed as a week.

## Style
English. Formal but not stiff. No filler openings. Do not begin with "In this report". Write dates as 19 September 2026. Name every source file you used at the very end under the heading "Sources".

## When information is missing
Say exactly what is missing, in which file you expected it, and what you did instead. Never silently skip a section: write the section heading and the sentence "Not enough data in the source for this section."
